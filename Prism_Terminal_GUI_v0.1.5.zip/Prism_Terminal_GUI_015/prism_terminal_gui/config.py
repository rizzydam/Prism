import os, sys, toml
from dataclasses import dataclass, field
from typing import Dict, Any

def _platform_config_dir() -> str:
    home = os.path.expanduser("~")
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA", os.path.join(home, "AppData", "Roaming"))
        return os.path.join(base, "PrismTerminal")
    elif sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", "PrismTerminal")
    else:
        return os.path.join(home, ".config", "prism_terminal")

@dataclass
class AppConfig:
    app: Dict[str, Any] = field(default_factory=lambda: {"first_run_complete": False, "theme": "light"})
    network: Dict[str, Any] = field(default_factory=lambda: {"base_url": "", "timeout": 8.0})
    keys: Dict[str, Any] = field(default_factory=lambda: {"index": ["default"], "default": "default"})
    logging: Dict[str, Any] = field(default_factory=lambda: {"level": "INFO"})
    plugins: Dict[str, Any] = field(default_factory=lambda: {"enabled": []})
    profiles: Dict[str, Any] = field(default_factory=lambda: {"items": []})

class ConfigManager:
    def __init__(self):
        self.config_dir = _platform_config_dir()
        self.config_file = os.path.join(self.config_dir, "config.toml")
        os.makedirs(self.config_dir, exist_ok=True)

    def load(self) -> AppConfig:
        cfg = AppConfig()
        if os.path.exists(self.config_file):
            try:
                data = toml.load(self.config_file)
            except Exception:
                data = {}
            for section in ["app","network","keys","logging","plugins","profiles"]:
                if section in data and isinstance(getattr(cfg, section), dict):
                    getattr(cfg, section).update(data.get(section) or {})
        return cfg

    def save(self, cfg: AppConfig) -> None:
        data = {
            "app": cfg.app, "network": cfg.network, "keys": cfg.keys,
            "logging": cfg.logging, "plugins": cfg.plugins, "profiles": cfg.profiles
        }
        os.makedirs(self.config_dir, exist_ok=True)
        with open(self.config_file, "w", encoding="utf-8") as f:
            toml.dump(data, f)

    def open_config_dir(self):
        path = self.config_dir
        if sys.platform.startswith("win"): os.startfile(path)  # type: ignore
        elif sys.platform == "darwin": os.system(f'open "{path}"')
        else: os.system(f'xdg-open "{path}"')
        
    def open_config_file(self):
        path = self.config_file
        if sys.platform.startswith("win"): os.startfile(path)  # type: ignore
        elif sys.platform == "darwin": os.system(f'open "{path}"')
        else: os.system(f'xdg-open "{path}"')
