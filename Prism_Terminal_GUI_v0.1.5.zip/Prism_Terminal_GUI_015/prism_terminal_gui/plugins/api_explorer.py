from tkinter import ttk, messagebox
import tkinter as tk
import json, requests

def build_ui(parent, services):
    cfg = services["cfg"]; keystore = services["keystore"]

    frame = ttk.Frame(parent)
    ttk.Label(frame, text="API Explorer", font=("Helvetica", 12, "bold")).pack(anchor="w", pady=(4,6))

    top = ttk.Frame(frame); top.pack(fill="x", padx=2, pady=2)
    ttk.Label(top, text="Method").pack(side="left")
    cmb_method = ttk.Combobox(top, values=["GET","POST","PUT","PATCH","DELETE"], width=8, state="readonly"); cmb_method.set("GET"); cmb_method.pack(side="left", padx=(6,10))

    ttk.Label(top, text="Path").pack(side="left")
    ent_path = ttk.Entry(top, width=60); ent_path.insert(0, "/v1/marketstatus/now"); ent_path.pack(side="left", padx=(6,10))

    ttk.Label(top, text="Auth").pack(side="left")
    cmb_auth = ttk.Combobox(top, values=["inherit","none","bearer","query_apikey"], width=14, state="readonly"); cmb_auth.set("inherit"); cmb_auth.pack(side="left", padx=(6,6))

    ttk.Label(top, text="Key").pack(side="left")
    names = keystore.list_names(cfg) or ["default"]
    cmb_key = ttk.Combobox(top, values=names, width=12, state="readonly")
    if cfg.keys.get("default") in names: cmb_key.set(cfg.keys.get("default"))
    elif names: cmb_key.set(names[0])
    cmb_key.pack(side="left", padx=(6,10))

    mid = ttk.Frame(frame); mid.pack(fill="x", padx=2, pady=2)
    ttk.Label(mid, text="Query (k=v&k2=v2)").pack(side="left")
    ent_q = ttk.Entry(mid, width=50); ent_q.pack(side="left", padx=(6,10))
    ttk.Label(mid, text="Headers (k:v per line)").pack(side="left")
    ent_h = tk.Text(mid, height=3, width=40); ent_h.pack(side="left")

    bodyrow = ttk.Frame(frame); bodyrow.pack(fill="both", expand=True, padx=2, pady=4)
    ttk.Label(bodyrow, text="Body (JSON)").pack(anchor="w")
    txt_body = tk.Text(bodyrow, height=6); txt_body.pack(fill="both", expand=True)

    btn_row = ttk.Frame(frame); btn_row.pack(fill="x", pady=6)
    ttk.Button(btn_row, text="Send", command=lambda: send()).pack(side="left", padx=4)

    out = tk.Text(frame, height=14); out.pack(fill="both", expand=True, pady=(4,0))

    def auth_mode():
        sel = cmb_auth.get()
        if sel == "inherit":
            auth = cfg.plugins.get("auth", {})
            return auth.get("mode","none"), auth.get("query_key_param","apiKey")
        elif sel == "query_apikey":
            return "query_apikey", cfg.plugins.get("auth",{}).get("query_key_param","apiKey")
        else:
            return sel, cfg.plugins.get("auth",{}).get("query_key_param","apiKey")

    def parse_headers(text):
        hdrs = {}
        for line in text.splitlines():
            if not line.strip() or ":" not in line: continue
            k,v = line.split(":",1); hdrs[k.strip()] = v.strip()
        return hdrs

    def parse_query(text):
        q = {}
        for part in text.split("&"):
            if not part.strip() or "=" not in part: continue
            k,v = part.split("=",1); q[k.strip()] = v.strip()
        return q

    def send():
        base = (cfg.network.get("base_url") or "").rstrip("/")
        if not base:
            messagebox.showerror("API Explorer", "Base URL not configured (Settings)."); return
        url = base + ent_path.get().strip()
        qs = parse_query(ent_q.get().strip()); hdrs = parse_headers(ent_h.get("1.0","end"))

        mode, qname = auth_mode()
        keyname = cmb_key.get() or cfg.keys.get("default"); keyval = keystore.get(keyname) if keyname else None
        if mode == "bearer" and keyval: hdrs["Authorization"] = f"Bearer {keyval}"
        elif mode == "query_apikey" and keyval: qs[qname or "apiKey"] = keyval

        data = None
        if cmb_method.get() in ("POST","PUT","PATCH"):
            txt = txt_body.get("1.0","end").strip()
            if txt:
                try: data = json.loads(txt)
                except Exception as e:
                    messagebox.showerror("API Explorer", f"Body JSON invalid: {e}"); return

        def task():
            try:
                resp = requests.request(cmb_method.get(), url, params=qs, json=data, headers=hdrs, timeout=float(cfg.network.get("timeout",8.0)))
                try:
                    j = resp.json(); content = f"HTTP {resp.status_code}\n\n" + json.dumps(j, indent=2)[:100000]
                except Exception:
                    content = f"HTTP {resp.status_code}\n\n" + resp.text[:100000]
            except Exception as e:
                content = f"Error: {e}"
            def ui():
                out.configure(state="normal"); out.delete("1.0","end"); out.insert("end", content); out.configure(state="disabled")
            parent.after(0, ui)
        services["run_in_thread"](task)

    return frame

PLUGIN = {"name":"API Explorer","version":"0.1.4","api_version":1,"build_ui":build_ui,"description":"Send requests with auth modes."}
