from tkinter import ttk, messagebox
import tkinter as tk

def build_ui(parent, services):
    cfg = services["cfg"]; cfgmgr = services["cfgmgr"]; log = services["log"]

    if not hasattr(cfg, "profiles"):
        try: cfg.profiles = {"items": []}; cfgmgr.save(cfg)
        except Exception: pass

    frame = ttk.Frame(parent)
    ttk.Label(frame, text="Profiles (environments)", font=("Helvetica", 12, "bold")).pack(anchor="w", pady=(4,6))

    cols = ("name","base_url","auth","default_key","notes")
    tree = ttk.Treeview(frame, columns=cols, show="headings", height=10)
    for c, w in zip(cols, (120,260,100,120,240)):
        tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    tree.pack(fill="both", expand=True)

    btns = ttk.Frame(frame); btns.pack(anchor="w", pady=6)
    ttk.Button(btns, text="Add", command=lambda: edit_profile()).pack(side="left", padx=3)
    ttk.Button(btns, text="Edit", command=lambda: on_edit()).pack(side="left", padx=3)
    ttk.Button(btns, text="Delete", command=lambda: on_delete()).pack(side="left", padx=3)
    ttk.Button(btns, text="Activate", command=lambda: on_activate()).pack(side="left", padx=10)

    ttk.Label(frame, text="Auth modes: none, bearer, query_apikey. Query key param defaults to 'apiKey'.", foreground="#555").pack(anchor="w", pady=(4,2))

    def refresh():
        tree.delete(*tree.get_children())
        items = (getattr(cfg, "profiles", {}) or {}).get("items", [])
        for p in items:
            tree.insert("", "end", values=(
                p.get("name",""), p.get("base_url",""), p.get("auth_mode","none"),
                p.get("default_key",""), p.get("notes","")
            ))

    def selected():
        sel = tree.selection()
        if not sel: return None, None
        idx = tree.index(sel[0])
        items = (getattr(cfg, "profiles", {}) or {}).get("items", [])
        if 0 <= idx < len(items): return idx, items[idx]
        return None, None

    def on_edit():
        idx, prof = selected()
        if idx is None: messagebox.showinfo("Profiles", "Select a profile to edit."); return
        edit_profile(existing=(idx, prof))

    def on_delete():
        idx, prof = selected()
        if idx is None: messagebox.showinfo("Profiles", "Select a profile to delete."); return
        if messagebox.askyesno("Profiles", f"Delete profile '{prof.get('name','')}'?"):
            arr = list((getattr(cfg, "profiles", {}) or {}).get("items", []))
            arr.pop(idx); cfg.profiles = {"items": arr}; cfgmgr.save(cfg); log(f"Profile deleted: {prof.get('name','')}"); refresh()

    def on_activate():
        idx, prof = selected()
        if idx is None: messagebox.showinfo("Profiles", "Select a profile to activate."); return
        cfg.network["base_url"] = (prof.get("base_url","") or "").strip()
        default_key = (prof.get("default_key") or "").strip()
        if default_key: cfg.keys["default"] = default_key
        cfg.plugins.setdefault("auth", {})
        cfg.plugins["auth"]["mode"] = prof.get("auth_mode","none")
        cfg.plugins["auth"]["query_key_param"] = prof.get("query_key_param","apiKey")
        cfgmgr.save(cfg); log(f"Activated profile '{prof.get('name','')}'."); messagebox.showinfo("Profiles", f"Activated '{prof.get('name','')}'.")

    def edit_profile(existing=None):
        window = tk.Toplevel(frame); window.title("Edit Profile" if existing else "Add Profile"); window.geometry("520x380")

        ttk.Label(window, text="Name").pack(anchor="w", padx=8, pady=(10,0)); ent_name = ttk.Entry(window); ent_name.pack(fill="x", padx=8)
        ttk.Label(window, text="Base URL").pack(anchor="w", padx=8, pady=(10,0)); ent_url = ttk.Entry(window); ent_url.pack(fill="x", padx=8)
        ttk.Label(window, text="Default Key Name").pack(anchor="w", padx=8, pady=(10,0)); ent_key = ttk.Entry(window); ent_key.pack(fill="x", padx=8)
        ttk.Label(window, text="Auth Mode (none / bearer / query_apikey)").pack(anchor="w", padx=8, pady=(10,0)); ent_auth = ttk.Combobox(window, values=["none","bearer","query_apikey"], state="readonly"); ent_auth.pack(fill="x", padx=8)
        ttk.Label(window, text="Query Key Param (if 'query_apikey')").pack(anchor="w", padx=8, pady=(10,0)); ent_qname = ttk.Entry(window); ent_qname.pack(fill="x", padx=8); ent_qname.insert(0, "apiKey")
        ttk.Label(window, text="Notes").pack(anchor="w", padx=8, pady=(10,0)); txt_notes = tk.Text(window, height=4); txt_notes.pack(fill="both", padx=8)

        if existing:
            i, prof = existing
            ent_name.insert(0, prof.get("name","")); ent_url.insert(0, prof.get("base_url",""))
            ent_key.insert(0, prof.get("default_key","")); ent_auth.set(prof.get("auth_mode","none"))
            ent_qname.delete(0,"end"); ent_qname.insert(0, prof.get("query_key_param","apiKey"))
            txt_notes.insert("1.0", prof.get("notes",""))

        row = ttk.Frame(window); row.pack(anchor="e", padx=8, pady=12)
        def on_save():
            name = ent_name.get().strip(); url = ent_url.get().strip(); dkey = ent_key.get().strip()
            auth = ent_auth.get().strip() or "none"; qname = ent_qname.get().strip() or "apiKey"; notes = txt_notes.get("1.0","end").strip()
            if not name: messagebox.showerror("Profiles", "Name is required."); return
            item = {"name": name, "base_url": url, "default_key": dkey, "auth_mode": auth, "query_key_param": qname, "notes": notes}
            arr = list((getattr(cfg, "profiles", {}) or {}).get("items", []))
            if existing: arr[i] = item
            else: arr.append(item)
            cfg.profiles = {"items": arr}; cfgmgr.save(cfg); window.destroy(); refresh()
        ttk.Button(row, text="Save", command=on_save).pack(side="right", padx=6)
        ttk.Button(row, text="Cancel", command=window.destroy).pack(side="right")

    refresh()
    return frame

PLUGIN = {"name":"Profiles","version":"0.1.4","api_version":1,"build_ui":build_ui,"description":"Create/activate environment profiles."}
