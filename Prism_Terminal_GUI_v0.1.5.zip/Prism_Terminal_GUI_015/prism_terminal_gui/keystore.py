import os
from typing import Optional, List
from .config import ConfigManager, AppConfig

SERVICE_NAME = "prism_terminal"

class KeyStore:
    def __init__(self, cfgmgr: ConfigManager):
        self.cfgmgr = cfgmgr
        try:
            import keyring
            self._kr = keyring
            self._kr_available = True
        except Exception:
            self._kr = None
            self._kr_available = False
        self._fallback_file = os.path.join(self.cfgmgr.config_dir, ".secrets.env")
        if not os.path.exists(self._fallback_file):
            with open(self._fallback_file, "w", encoding="utf-8") as f:
                f.write("# Prism Terminal secrets fallback\n")

    def list_names(self, conf: AppConfig) -> List[str]:
        return list(dict.fromkeys(conf.keys.get("index") or []))

    def get(self, name: str) -> Optional[str]:
        key = f"PRISM_{name.upper()}"
        if self._kr_available:
            try:
                return self._kr.get_password(SERVICE_NAME, key)  # type: ignore
            except Exception:
                pass
        return self._read_env_value(key)

    def set(self, name: str, value: str, conf: AppConfig) -> None:
        key = f"PRISM_{name.upper()}"
        if self._kr_available:
            try:
                self._kr.set_password(SERVICE_NAME, key, value)  # type: ignore
            except Exception:
                self._write_env_value(key, value)
        else:
            self._write_env_value(key, value)
        idx = conf.keys.get("index") or []
        if name not in idx:
            idx.append(name)
            conf.keys["index"] = idx

    def delete(self, name: str, conf: AppConfig) -> None:
        key = f"PRISM_{name.upper()}"
        if self._kr_available:
            try:
                self._kr.delete_password(SERVICE_NAME, key)  # type: ignore
            except Exception:
                pass
        self._remove_env_value(key)
        conf.keys["index"] = [n for n in conf.keys.get("index", []) if n != name]

    def _read_env_value(self, key: str):
        if not os.path.exists(self._fallback_file): return None
        try:
            with open(self._fallback_file, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip() or line.startswith("#") or "=" not in line: continue
                    k,v = line.strip().split("=",1)
                    if k == key: return v
        except Exception:
            return None
        return None

    def _write_env_value(self, key: str, value: str) -> None:
        lines = []
        if os.path.exists(self._fallback_file):
            with open(self._fallback_file, "r", encoding="utf-8") as f:
                lines = f.readlines()
        found = False
        for i,line in enumerate(lines):
            if line.strip().startswith(f"{key}="):
                lines[i] = f"{key}={value}\n"; found=True; break
        if not found: lines.append(f"{key}={value}\n")
        with open(self._fallback_file, "w", encoding="utf-8") as f:
            f.writelines(lines)

    def _remove_env_value(self, key: str) -> None:
        if not os.path.exists(self._fallback_file): return
        with open(self._fallback_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
        lines = [ln for ln in lines if not ln.strip().startswith(f"{key}=")]
        with open(self._fallback_file, "w", encoding="utf-8") as f:
            f.writelines(lines)
