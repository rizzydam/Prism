import os, sqlite3, json, time
from typing import Optional, Tuple

class SqlTTLCache:
    """Tiny SQLite-backed TTL cache stored in config_dir/cache.sqlite.
    Rows: key TEXT PRIMARY KEY, type TEXT, sym TEXT, ts REAL, data TEXT
    """
    def __init__(self, config_dir: str):
        self.path = os.path.join(config_dir, "cache.sqlite")
        os.makedirs(config_dir, exist_ok=True)
        self._ensure()

    def _ensure(self):
        con = sqlite3.connect(self.path)
        try:
            con.execute("CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, type TEXT, sym TEXT, ts REAL, data TEXT)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_cache_type_sym ON cache(type, sym)")
            con.commit()
        finally:
            con.close()

    def get(self, key: str, ttl: float) -> Optional[dict]:
        now = time.time()
        con = sqlite3.connect(self.path)
        try:
            cur = con.execute("SELECT ts, data FROM cache WHERE key=?", (key,))
            row = cur.fetchone()
            if not row: return None
            ts, data = row
            if now - float(ts) >= ttl: return None
            try:
                return json.loads(data)
            except Exception:
                return None
        finally:
            con.close()

    def set(self, key: str, typ: str, sym: str, value: dict):
        con = sqlite3.connect(self.path)
        try:
            con.execute("REPLACE INTO cache(key, type, sym, ts, data) VALUES(?,?,?,?,?)",
                        (key, typ, sym, time.time(), json.dumps(value)[:500000]))
            con.commit()
        finally:
            con.close()

    def purge(self, max_age_sec: float = 7*24*3600):
        cutoff = time.time() - max_age_sec
        con = sqlite3.connect(self.path)
        try:
            con.execute("DELETE FROM cache WHERE ts<?", (cutoff,))
            con.commit()
        finally:
            con.close()

    def clear_all(self):
        con = sqlite3.connect(self.path)
        try:
            con.execute("DELETE FROM cache"); con.commit()
        finally:
            con.close()
