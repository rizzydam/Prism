import time, requests, datetime, json, hashlib
from typing import Dict, Any, Optional, Tuple, List
from .sqlcache import SqlTTLCache

class MarketData:
    """Profile-aware data provider with TTL cache and batch snapshots (Polygon).
    TTLs: last=5s, prev=60s, batch=5s
    """
    def __init__(self, cfg, keystore, logger=None, cfgmgr=None):
        self.cfg = cfg
        self.keystore = keystore
        self.logger = logger
        self._sess = requests.Session()
        self.ttl_last = 5.0
        self.ttl_prev = 60.0
        self.ttl_batch = 5.0
        self._mem_cache: Dict[Tuple[str,str], Tuple[float, Any]] = {}
        self._sql = SqlTTLCache(cfgmgr.config_dir) if cfgmgr is not None else None

    # ---------- public API ----------
    def clear_cache(self):
        self._mem_cache.clear()
        if self._sql: self._sql.clear_all()

    def last_trade(self, symbol: str) -> Dict[str, Any]:
        key = ("last", symbol.upper())
        cached = self._get_cache(key, self.ttl_last)
        if cached is not None: return cached
        base, headers, params = self._auth()
        if not base: return {"ok": False, "error": "Base URL not configured."}
        url = f"{base}/v2/last/trade/{symbol.upper()}"
        try:
            r = self._sess.get(url, headers=headers, params=params, timeout=float(self.cfg.network.get("timeout", 8.0)))
            data = _safe_json(r)
            price, ts = _extract_last_trade(data)
            res = {"ok": r.ok, "price": price, "ts": ts, "raw": data, "status": r.status_code}
            if not r.ok and not res.get("error"): res["error"] = str(data)[:300]
        except Exception as e:
            res = {"ok": False, "error": str(e)}
        self._put_cache(key, res)
        return res

    def prev_close(self, symbol: str) -> Dict[str, Any]:
        key = ("prev", symbol.upper())
        cached = self._get_cache(key, self.ttl_prev)
        if cached is not None: return cached
        base, headers, params = self._auth()
        if not base: return {"ok": False, "error": "Base URL not configured."}
        params2 = dict(params); params2.update({"adjusted": "true"})
        url = f"{base}/v2/aggs/ticker/{symbol.upper()}/prev"
        try:
            r = self._sess.get(url, headers=headers, params=params2, timeout=float(self.cfg.network.get("timeout", 8.0)))
            data = _safe_json(r)
            close = _extract_prev_close(data)
            res = {"ok": r.ok, "close": close, "raw": data, "status": r.status_code}
            if not r.ok and not res.get("error"): res["error"] = str(data)[:300]
        except Exception as e:
            res = {"ok": False, "error": str(e)}
        self._put_cache(key, res)
        return res

    def batch_quotes(self, symbols: List[str]) -> Dict[str, Dict[str, Any]]:
        """Return mapping symbol -> {ok,last,prev,change,pct,ts,error?} using cache + snapshots.
        Falls back to per-symbol if snapshots not available.
        """
        symbols = [s.upper() for s in symbols if s and isinstance(s, str)]
        out: Dict[str, Dict[str, Any]] = {}
        # First, fetch any fresh cached values
        fresh = {}
        stale = []
        for s in symbols:
            last = self._get_cache(("last", s), self.ttl_last)
            prev = self._get_cache(("prev", s), self.ttl_prev)
            if last is not None and prev is not None:
                out[s] = _combine_last_prev(last, prev)
                fresh[s] = True
            else:
                stale.append(s)

        if not stale:
            return out

        # Try snapshots when base looks like Polygon and use_snapshots enabled
        use_snapshots = bool(self.cfg.plugins.get("watchlist", {}).get("use_snapshots", True))
        base, headers, params = self._auth()
        is_polygon = base and ("polygon.io" in base)
        batch_size = int(self.cfg.plugins.get("watchlist", {}).get("batch_size", 20) or 20)
        if use_snapshots and is_polygon:
            chunks = [stale[i:i+batch_size] for i in range(0, len(stale), batch_size)]
            for chunk in chunks:
                self._snapshot_chunk(base, headers, params, chunk, out)
        # Any still missing -> per-symbol fallback
        missing = [s for s in stale if s not in out]
        for s in missing:
            l = self.last_trade(s); p = self.prev_close(s)
            out[s] = _combine_last_prev(l, p)
        return out

    # ---------- internals ----------
    def _snapshot_chunk(self, base: str, headers: dict, params: dict, syms: List[str], out: Dict[str, Dict[str, Any]]):
        url = f"{base}/v2/snapshot/locale/us/markets/stocks/tickers"
        p = dict(params)
        p["tickers"] = ",".join(syms)
        try:
            r = self._sess.get(url, headers=headers, params=p, timeout=float(self.cfg.network.get("timeout", 8.0)))
            data = _safe_json(r)
            results = data.get("results") or data.get("ticker") or data.get("tickers") or []
            # results expected: list of ticker snapshots
            for item in (results if isinstance(results, list) else []):
                sym = item.get("ticker") or item.get("symbol")
                if not sym: continue
                last = _extract_last_from_snapshot(item)
                prev = _extract_prev_from_snapshot(item)
                ts = _extract_ts_from_snapshot(item)
                last_obj = {"ok": last is not None, "price": last, "ts": ts, "raw": item, "status": r.status_code}
                prev_obj = {"ok": prev is not None, "close": prev, "raw": item, "status": r.status_code}
                self._put_cache(("last", sym), last_obj)
                self._put_cache(("prev", sym), prev_obj)
                out[sym] = _combine_last_prev(last_obj, prev_obj)
            # Note: symbols not in response remain missing and will be fetched individually by caller
        except Exception as e:
            if self.logger: self.logger.warning(f"Snapshot batch failed: {e}")

    def _auth(self) -> tuple[str, dict, dict]:
        base = (self.cfg.network.get("base_url") or "").rstrip("/")
        auth = self.cfg.plugins.get("auth", {})
        mode = (auth.get("mode") or "none").strip()
        qname = (auth.get("query_key_param") or "apiKey").strip() or "apiKey"
        keyname = "polygon" if "polygon" in (self.cfg.keys.get("index") or []) else self.cfg.keys.get("default")
        key = self.keystore.get(keyname) if keyname else None
        headers = {"User-Agent": "PrismTerminal/0.1"}
        params = {}
        if mode == "bearer" and key:
            headers["Authorization"] = f"Bearer {key}"
        elif mode == "query_apikey" and key:
            params[qname] = key
        return base, headers, params

    def _get_cache(self, key: tuple, ttl: float):
        # try mem
        now = time.time()
        item = self._mem_cache.get(key)
        if item:
            ts, val = item
            if now - ts < ttl: return val
        # try sql
        if self._sql:
            k = self._sql_key(key)
            val = self._sql.get(k, ttl)
            if val is not None:
                # refresh in-memory copy
                self._mem_cache[key] = (now, val)
                return val
        return None

    def _put_cache(self, key: tuple, val: dict):
        now = time.time()
        self._mem_cache[key] = (now, val)
        if self._sql:
            typ, sym = key
            self._sql.set(self._sql_key(key), typ, sym, val)

    def _sql_key(self, key: tuple) -> str:
        typ, sym = key
        return f"{typ}:{sym}"

def _safe_json(resp):
    try:
        return resp.json()
    except Exception:
        return {"text": resp.text[:500]}

def _extract_last_trade(data: dict):
    last = data.get("results") or data.get("last") or data
    price = None
    ts = None
    if isinstance(last, dict):
        price = last.get("p") or last.get("price") or last.get("lastPrice") or last.get("lp" )
        ts = last.get("t") or last.get("timestamp") or last.get("ts")
    return price, ts

def _extract_prev_close(data: dict):
    rs = data.get("results") or data.get("result") or None
    if isinstance(rs, list) and rs:
        return rs[0].get("c") or rs[0].get("close")
    if isinstance(rs, dict):
        return rs.get("c") or rs.get("close")
    return None

def _extract_last_from_snapshot(item: dict):
    # polygon snapshot: lastTrade.p
    lastTrade = item.get("lastTrade") or {}
    return lastTrade.get("p") or lastTrade.get("price") or None

def _extract_ts_from_snapshot(item: dict):
    lastTrade = item.get("lastTrade") or {}
    return lastTrade.get("t") or lastTrade.get("timestamp") or None

def _extract_prev_from_snapshot(item: dict):
    # polygon snapshot: day.c
    day = item.get("day") or {}
    return day.get("c") or day.get("close") or None

def _combine_last_prev(last_obj: dict, prev_obj: dict) -> dict:
    last = last_obj.get("price"); prev = prev_obj.get("close")
    ok = bool(last is not None and prev is not None)
    chg = pct = None
    if isinstance(last, (int,float)) and isinstance(prev,(int,float)):
        chg = last - prev
        pct = (chg / prev) * 100.0 if prev != 0 else None
    return {
        "ok": ok or last_obj.get("ok") or prev_obj.get("ok"),
        "last": last, "prev": prev, "change": chg, "pct": pct,
        "ts": last_obj.get("ts"), "status": last_obj.get("status") or prev_obj.get("status"),
        "last_raw": last_obj.get("raw"), "prev_raw": prev_obj.get("raw"),
        "error": last_obj.get("error") or prev_obj.get("error")
    }
