import threading, time, uuid, traceback
from dataclasses import dataclass, field
from typing import Callable, Any, Dict, List, Optional

class JobStatus:
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"
    CANCELLED = "cancelled"

@dataclass
class Job:
    id: str
    name: str
    fn: Callable
    args: tuple = field(default_factory=tuple)
    kwargs: dict = field(default_factory=dict)
    status: str = JobStatus.QUEUED
    progress: float = 0.0
    message: str = ""
    attempts: int = 0
    max_retries: int = 0
    backoff: float = 1.5
    started_at: float = 0.0
    ended_at: float = 0.0
    last_error: str = ""
    cancel_event: threading.Event = field(default_factory=threading.Event)

class JobContext:
    def __init__(self, job: Job, manager: 'JobManager'):
        self._job = job
        self._mgr = manager

    def update_progress(self, pct: float, message: Optional[str] = None):
        self._mgr._set_progress(self._job.id, pct, message or "")

    def is_cancelled(self) -> bool:
        return self._job.cancel_event.is_set()

    def check_cancelled(self):
        if self.is_cancelled():
            raise RuntimeError("cancelled")

    def sleep(self, seconds: float, step: float = 0.1):
        t = 0.0
        while t < seconds:
            if self.is_cancelled():
                raise RuntimeError("cancelled")
            time.sleep(min(step, seconds - t))
            t += step

class JobManager:
    def __init__(self, logger=None, max_workers: int = 2):
        self._lock = threading.RLock()
        self._jobs: Dict[str, Job] = {}
        self._queue: List[str] = []
        self._running = 0
        self._max_workers = max_workers
        self._logger = logger
        self._dispatcher = threading.Thread(target=self._dispatch_loop, daemon=True)
        self._stop_event = threading.Event()
        self._dispatcher.start()

    def enqueue(self, fn: Callable, name: str, args: tuple = (), kwargs: dict = None, retries: int = 0, backoff: float = 1.5) -> str:
        if kwargs is None: kwargs = {}
        jid = uuid.uuid4().hex[:12]
        job = Job(id=jid, name=name, fn=fn, args=args, kwargs=kwargs, max_retries=retries, backoff=backoff)
        with self._lock:
            self._jobs[jid] = job
            self._queue.append(jid)
        if self._logger: self._logger.info("Job enqueued: %s (%s)", name, jid)
        return jid

    def cancel(self, job_id: str):
        with self._lock:
            job = self._jobs.get(job_id)
            if job and job.status in (JobStatus.QUEUED, JobStatus.RUNNING):
                job.cancel_event.set()
                if self._logger: self._logger.info("Job cancel requested: %s", job_id)

    def purge_finished(self):
        with self._lock:
            for jid in list(self._jobs.keys()):
                if self._jobs[jid].status in (JobStatus.SUCCESS, JobStatus.CANCELLED, JobStatus.ERROR):
                    self._jobs.pop(jid, None)
                    try:
                        self._queue.remove(jid)
                    except ValueError:
                        pass

    def get_snapshot(self) -> List[Dict[str, Any]]:
        with self._lock:
            snaps = []
            for j in self._jobs.values():
                snaps.append({
                    "id": j.id, "name": j.name, "status": j.status, "progress": j.progress,
                    "message": j.message, "attempts": j.attempts, "max_retries": j.max_retries,
                    "started_at": j.started_at, "ended_at": j.ended_at, "last_error": j.last_error
                })
            return snaps

    def _set_progress(self, job_id: str, pct: float, message: str):
        with self._lock:
            j = self._jobs.get(job_id)
            if j:
                j.progress = max(0.0, min(100.0, float(pct)))
                j.message = message

    def _dispatch_loop(self):
        while not self._stop_event.is_set():
            try:
                self._tick()
            except Exception as e:
                if self._logger: self._logger.exception("Job dispatcher error: %s", e)
            time.sleep(0.1)

    def _tick(self):
        with self._lock:
            while self._running < self._max_workers and self._queue:
                next_id = None
                for jid in self._queue:
                    j = self._jobs.get(jid)
                    if j and j.status == JobStatus.QUEUED:
                        next_id = jid
                        break
                if not next_id: break
                self._start_job(next_id)

    def _start_job(self, jid: str):
        job = self._jobs.get(jid)
        if not job: return
        job.status = JobStatus.RUNNING
        job.started_at = time.time()
        self._running += 1
        if self._logger: self._logger.info("Job started: %s (%s)", job.name, jid)

        def run_once(delay: float = 0.0):
            if delay > 0: time.sleep(delay)
            ctx = JobContext(job, self)
            try:
                job.attempts += 1
                job.fn(ctx, *job.args, **job.kwargs)
                with self._lock:
                    job.status = JobStatus.SUCCESS
                    job.progress = 100.0
                    job.ended_at = time.time()
            except Exception as e:
                msg = str(e)
                if job.cancel_event.is_set():
                    with self._lock:
                        job.status = JobStatus.CANCELLED
                        job.ended_at = time.time()
                        job.last_error = msg or "cancelled"
                else:
                    with self._lock:
                        job.last_error = msg
                        if job.attempts <= job.max_retries:
                            delay = (job.backoff ** (job.attempts - 1))
                            job.status = JobStatus.QUEUED
                            job.started_at = 0.0; job.ended_at = 0.0
                        else:
                            job.status = JobStatus.ERROR
                            job.ended_at = time.time()
            finally:
                with self._lock:
                    self._running = max(0, self._running - 1)

        threading.Thread(target=run_once, daemon=True).start()
