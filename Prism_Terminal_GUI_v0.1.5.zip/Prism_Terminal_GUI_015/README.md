# Prism Terminal GUI (v0.1.5)

Stable, Prism-branded GUI terminal with a plugin bay.

**What's new in 0.1.5**
- **Snapshot batching + faster refresh** — Watchlist now fetches multiple symbols in a single call (Polygon snapshots when available).
- **Persistent SQLite cache** — small TTL cache persisted under your config folder to reduce flicker and API calls.
- Still includes: Watchlist + Quote Tiles, MarketData service, Profiles, API Explorer, Polygon Market, Jobs.
- Existing: Profiles, API Explorer, Polygon Market, Jobs.

**Quickstart (Windows)**
```
install.bat
run.bat
```

**Quickstart (macOS/Linux)**
```bash
chmod +x install.sh run.sh
./install.sh
./run.sh
```

**Where your watchlist lives**
`config.toml` → `[plugins.watchlist]` (symbols, autorefresh_sec)
