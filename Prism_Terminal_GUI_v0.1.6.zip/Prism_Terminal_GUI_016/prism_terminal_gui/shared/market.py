import time, requests, datetime, json, sqlite3, os
from typing import Dict, Any, Optional, Tuple, List

class MarketData:
    """Profile-aware market data with memory + SQLite TTL cache and batch snapshots."""
    def __init__(self, cfg, keystore, logger=None, config_dir: Optional[str]=None):
        self.cfg = cfg
        self.keystore = keystore
        self.logger = logger
        self._sess = requests.Session()
        self._cache: Dict[Tuple[str,str], Tuple[float, Any]] = {}
        # TTLs (seconds)
        self.ttl_last = 5.0
        self.ttl_prev = 60.0
        self.ttl_snap = 3.0
        # SQLite cache
        if config_dir is None:
            # try to locate from cfgmgr via cfg path hints; caller may pass explicitly
            config_dir = os.path.expanduser("~")
        self.db_path = os.path.join(config_dir, "prism_cache.db")
        self._ensure_db()

    # ---------- public API ----------
    def clear_cache(self):
        self._cache.clear()
        try:
            con = sqlite3.connect(self.db_path)
            with con:
                con.execute("DELETE FROM cache")
            con.close()
        except Exception:
            pass

    def last_trade(self, symbol: str) -> Dict[str, Any]:
        """Fetch last trade for symbol. Returns {ok, price, ts, raw, error?}."""
        symbol = symbol.upper()
        cache_key = ("last", symbol)
        cached = self._get_cache(cache_key, self.ttl_last)
        if cached is not None: return cached
        base, headers, params = self._auth()
        if not base:
            return {"ok": False, "error": "Base URL not configured."}
        url = f"{base}/v2/last/trade/{symbol}"
        try:
            r = self._sess.get(url, headers=headers, params=params, timeout=float(self.cfg.network.get("timeout", 8.0)))
            data = _safe_json(r)
            price, ts = _extract_last_trade(data)
            res = {"ok": r.ok, "price": price, "ts": ts, "raw": data, "status": r.status_code}
            if not r.ok and not res.get("error"): res["error"] = str(data)[:300]
        except Exception as e:
            res = {"ok": False, "error": str(e)}
        self._put_cache(cache_key, res)
        return res

    def prev_close(self, symbol: str) -> Dict[str, Any]:
        """Fetch previous close aggregate. Returns {ok, close, raw, error?}."""
        symbol = symbol.upper()
        cache_key = ("prev", symbol)
        cached = self._get_cache(cache_key, self.ttl_prev)
        if cached is not None: return cached
        base, headers, params = self._auth()
        if not base:
            return {"ok": False, "error": "Base URL not configured."}
        params2 = dict(params); params2.update({"adjusted": "true"})
        url = f"{base}/v2/aggs/ticker/{symbol}/prev"
        try:
            r = self._sess.get(url, headers=headers, params=params2, timeout=float(self.cfg.network.get("timeout", 8.0)))
            data = _safe_json(r)
            close = _extract_prev_close(data)
            res = {"ok": r.ok, "close": close, "raw": data, "status": r.status_code}
            if not r.ok and not res.get("error"): res["error"] = str(data)[:300]
        except Exception as e:
            res = {"ok": False, "error": str(e)}
        self._put_cache(cache_key, res)
        return res

    def batch_quotes(self, symbols: List[str]) -> Dict[str, Dict[str, Any]]:
        """Batch snapshot for many symbols. Returns dict of symbol -> {ok, last, prev, change, pct, ts, status?, error?}."""
        syms = [s.upper() for s in symbols if s and isinstance(s, str)]
        out: Dict[str, Dict[str, Any]] = {}
        # Try cache first for each symbol
        now = time.time()
        missing = []
        for s in syms:
            item = self._get_cache(("snap", s), self.ttl_snap)
            if item is not None:
                out[s] = item
            else:
                missing.append(s)
        if not missing:
            return out

        base, headers, params = self._auth()
        if not base:
            for s in missing:
                out[s] = {"ok": False, "error": "Base URL not configured."}
            return out

        # Chunk to avoid URL size issues; Polygon handles long lists, but we'll be conservative
        chunk = 50
        for i in range(0, len(missing), chunk):
            batch = missing[i:i+chunk]
            url = f"{base}/v2/snapshot/locale/us/markets/stocks/tickers"
            params2 = dict(params); params2["tickers"] = ",".join(batch)
            try:
                r = self._sess.get(url, headers=headers, params=params2, timeout=float(self.cfg.network.get("timeout", 8.0)))
                data = _safe_json(r)
                # Parse snapshots
                # Expect shape: { "tickers": [ { "ticker": "AAPL", "lastTrade": {"p": ...,"t": ...}, "prevDay": {"c": ...}, "day": {...}, "updated": ... }, ... ] }
                tickers = data.get("tickers") or data.get("results") or []
                found = set()
                for t in tickers:
                    sym = (t.get("ticker") or t.get("T") or "").upper()
                    last = None
                    ts = None
                    prev = None
                    lt = t.get("lastTrade") or t.get("ltp") or t.get("last") or {}
                    if isinstance(lt, dict):
                        last = lt.get("p") or lt.get("price") or lt.get("lp")
                        ts = lt.get("t") or lt.get("timestamp") or t.get("updated")
                    # prev close from prevDay or day close
                    pd = t.get("prevDay") or t.get("prev") or {}
                    if isinstance(pd, dict):
                        prev = pd.get("c") or pd.get("close")
                    if prev is None:
                        day = t.get("day") or {}
                        if isinstance(day, dict):
                            prev = day.get("c") or day.get("close")
                    chg = pct = None
                    if isinstance(prev, (int,float)) and isinstance(last, (int,float)):
                        chg = last - prev
                        if prev != 0:
                            pct = (chg / prev) * 100.0
                    row = {"ok": True, "last": last, "prev": prev, "change": chg, "pct": pct, "ts": ts, "status": getattr(r, "status_code", None)}
                    if sym:
                        out[sym] = row
                        self._put_cache(("snap", sym), row, kind="snap")
                        found.add(sym)
                # Any missing from this batch -> fallback
                for s in batch:
                    if s not in found:
                        out[s] = self._fallback_quote(s)
            except Exception as e:
                # Total failure for this chunk -> fallback each
                for s in batch:
                    out[s] = self._fallback_quote(s, err=str(e))

        return out

    # ---------- helpers ----------
    def _fallback_quote(self, sym: str, err: Optional[str]=None) -> Dict[str, Any]:
        p = self.prev_close(sym)
        l = self.last_trade(sym)
        prev = p.get("close"); last = l.get("price")
        chg = pct = None
        if isinstance(prev,(int,float)) and isinstance(last,(int,float)):
            chg = last - prev
            if prev: pct = (chg/prev)*100.0
        ts = l.get("ts")
        row = {"ok": bool(l.get("ok")) and bool(p.get("ok")), "last": last, "prev": prev, "change": chg, "pct": pct, "ts": ts}
        if err and not row["ok"]:
            row["error"] = err
        self._put_cache(("snap", sym.upper()), row, kind="snap")
        return row

    def _auth(self) -> tuple[str, dict, dict]:
        base = (self.cfg.network.get("base_url") or "").rstrip("/")
        auth = self.cfg.plugins.get("auth", {})
        mode = (auth.get("mode") or "none").strip()
        qname = (auth.get("query_key_param") or "apiKey").strip() or "apiKey"
        # prefer a key named 'polygon', else default
        idx = self.cfg.keys.get("index") or []
        keyname = "polygon" if "polygon" in idx else self.cfg.keys.get("default")
        key = self.keystore.get(keyname) if keyname else None
        headers = {"User-Agent": "PrismTerminal/0.1"}
        params = {}
        if mode == "bearer" and key:
            headers["Authorization"] = f"Bearer {key}"
        elif mode == "query_apikey" and key:
            params[qname] = key
        return base, headers, params

    def _ensure_db(self):
        try:
            con = sqlite3.connect(self.db_path)
            with con:
                con.execute("CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, ts REAL, value TEXT)")
            con.close()
        except Exception:
            pass

    def _db_get(self, key: Tuple[str,str]) -> Optional[Tuple[float, Any]]:
        import json, sqlite3
        k = f"{key[0]}:{key[1]}"
        try:
            con = sqlite3.connect(self.db_path)
            cur = con.cursor()
            cur.execute("SELECT ts, value FROM cache WHERE key=?", (k,))
            row = cur.fetchone()
            con.close()
            if not row: return None
            ts, val = row
            return float(ts), json.loads(val)
        except Exception:
            return None

    def _db_put(self, key: Tuple[str,str], val: Any):
        import json, sqlite3, time
        k = f"{key[0]}:{key[1]}"
        try:
            con = sqlite3.connect(self.db_path)
            with con:
                con.execute("INSERT OR REPLACE INTO cache(key, ts, value) VALUES (?,?,?)", (k, time.time(), json.dumps(val)))
            con.close()
        except Exception:
            pass

    def _get_cache(self, key: Tuple[str,str], ttl: float):
        now = time.time()
        item = self._cache.get(key)
        if item:
            ts, val = item
            if now - ts < ttl: return val
        # try DB
        row = self._db_get(key)
        if row:
            ts, val = row
            if now - ts < ttl:
                # warm memory cache
                self._cache[key] = (ts, val)
                return val
        return None

    def _put_cache(self, key: Tuple[str,str], val: Any, kind: str = ""):
        import time
        self._cache[key] = (time.time(), val)
        # persist
        try:
            self._db_put(key, val)
        except Exception:
            pass

def _safe_json(resp):
    try:
        return resp.json()
    except Exception:
        return {"text": getattr(resp, "text", "")[:500]}

def _extract_last_trade(data: dict):
    last = data.get("results") or data.get("last") or data
    price = None
    ts = None
    if isinstance(last, dict):
        price = last.get("p") or last.get("price") or last.get("lp")
        ts = last.get("t") or last.get("timestamp") or last.get("ts")
    return price, ts

def _extract_prev_close(data: dict):
    rs = data.get("results") or data.get("result") or None
    if isinstance(rs, list) and rs:
        return rs[0].get("c") or rs[0].get("close")
    if isinstance(rs, dict):
        return rs.get("c") or rs.get("close")
    return None
