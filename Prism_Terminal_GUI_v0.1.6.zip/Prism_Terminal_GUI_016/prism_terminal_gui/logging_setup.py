import os, logging
from logging.handlers import RotatingFileHandler

def get_log_dir(config_dir: str) -> str:
    log_dir = os.path.join(config_dir, "logs")
    os.makedirs(log_dir, exist_ok=True)
    return log_dir

def configure_logging(config_dir: str, level_name: str = "INFO", gui_append=None):
    logger = logging.getLogger("prism")
    logger.setLevel(getattr(logging, level_name.upper(), logging.INFO))
    logger.handlers.clear()
    log_dir = get_log_dir(config_dir)
    log_file = os.path.join(log_dir, "prism_terminal.log")
    fh = RotatingFileHandler(log_file, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(fh)
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    logger.addHandler(ch)
    if gui_append is not None:
        class GuiHandler(logging.Handler):
            def emit(self, record):
                try: gui_append(self.format(record) + "\n")
                except Exception: pass
        gh = GuiHandler()
        gh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        logger.addHandler(gh)
    return logger, log_file
