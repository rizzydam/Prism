from tkinter import ttk, messagebox
import tkinter as tk
import random

def build_ui(parent, services):
    jobs = services["jobs"]
    log = services["log"]

    frame = ttk.Frame(parent)
    ttk.Label(frame, text="Jobs & Task Runner", font=("Helvetica", 12, "bold")).pack(anchor="w", pady=(4,6))

    toolbar = ttk.Frame(frame); toolbar.pack(fill="x", pady=4)
    ttk.Label(toolbar, text="Test N").pack(side="left")
    ent_n = ttk.Entry(toolbar, width=8); ent_n.pack(side="left", padx=4); ent_n.insert(0, "100")
    ttk.Button(toolbar, text="Add Test Task", command=lambda: add_test()).pack(side="left", padx=4)
    ttk.Button(toolbar, text="Cancel", command=lambda: cancel_sel()).pack(side="left", padx=4)
    ttk.Button(toolbar, text="Retry", command=lambda: retry_sel()).pack(side="left", padx=4)
    ttk.Button(toolbar, text="Clear Finished", command=lambda: clear_finished()).pack(side="left", padx=4)

    cols = ("id","name","status","progress","attempts","message")
    tree = ttk.Treeview(frame, columns=cols, show="headings", height=14)
    for c, w in zip(cols, (120,220,100,80,80,380)):
        tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    tree.pack(fill="both", expand=True)

    def refresh():
        tree.delete(*tree.get_children())
        for j in jobs.get_snapshot():
            tree.insert("", "end", values=(
                j["id"], j["name"], j["status"], f'{j["progress"]:.0f}%', f'{j["attempts"]}/{j["max_retries"]}', j["message"]
            ))
        parent.after(700, refresh)

    def selected_id():
        sel = tree.selection()
        if not sel: return None
        return tree.item(sel[0])["values"][0]

    def clear_finished():
        jobs.purge_finished()

    def cancel_sel():
        jid = selected_id()
        if not jid: messagebox.showinfo("Jobs", "Select a job to cancel."); return
        jobs.cancel(jid)

    def retry_sel():
        jid = selected_id()
        if not jid: messagebox.showinfo("Jobs", "Select a job to retry."); return
        jobs.enqueue(demo_task, "Retry demo", args=(int(ent_n.get() or "100"),), kwargs={}, retries=1, backoff=1.5)

    def demo_task(ctx, N: int = 100):
        for i in range(N+1):
            if i % max(1, N//50) == 0:
                ctx.update_progress(i * 100.0 / max(1,N), f"Step {i}/{N}")
            ctx.sleep(0.02 + random.random()*0.01)
            ctx.check_cancelled()
        ctx.update_progress(100.0, "Done.")

    def add_test():
        try:
            N = int(ent_n.get() or "100")
        except Exception:
            messagebox.showerror("Jobs", "N must be an integer."); return
        jobs.enqueue(demo_task, f"Count to {N}", args=(N,), retries=1, backoff=1.5)
        log(f"Enqueued test job to count to {N}.")

    refresh()
    return frame

PLUGIN = {"name":"Jobs","version":"0.1.6","api_version":1,"build_ui":build_ui,"description":"Queue, progress, cancel, retry."}
