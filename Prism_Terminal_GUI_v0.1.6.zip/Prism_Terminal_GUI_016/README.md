# Prism Terminal GUI (v0.1.6)

Fixes + upgrade bundle:
- **Watchlist**: visible **Batch snapshot** toggle (ON by default). Uses Polygon snapshot API for multi-symbol refresh.
- **MarketData**: new `batch_quotes()` with robust parsing + **SQLite TTL cache**; memory + disk caching; clearable.
- **Alerts (new plugin)**: simple rules (Price ≥/≤, %Change ≥/≤) with Evaluate Now + Auto-evaluate; notifications via dialog + log.
- App: **Tools → Clear Data Cache**, **Zip Logs**, and `services["market"]` available to plugins.

## Quickstart (Windows)
```
install.bat
run.bat
```

## Quickstart (macOS/Linux)
```bash
chmod +x install.sh run.sh
./install.sh
./run.sh
```
