from tkinter import ttk, Frame, Label
APP_NAME = "Prism Terminal"
TAGLINE = "Stable core. Snap-on modules."
ACCENT = "#9b59b6"; ACCENT2 = "#3498db"
def header_frame(parent: Frame) -> Frame:
    f = ttk.Frame(parent)
    title = Label(f, text=APP_NAME, font=("Helvetica", 20, "bold"), fg=ACCENT)
    subtitle = Label(f, text=TAGLINE, font=("Helvetica", 11), fg=ACCENT2)
    title.pack(anchor="w"); subtitle.pack(anchor="w")
    return f
