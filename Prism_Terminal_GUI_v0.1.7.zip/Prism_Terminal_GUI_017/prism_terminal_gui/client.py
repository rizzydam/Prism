import requests
from typing import Optional
from .config import AppConfig

class Client:
    def __init__(self, cfg: AppConfig, api_key_value: Optional[str] = None):
        self.timeout = float(cfg.network.get("timeout", 8.0))
        self.base_url = (cfg.network.get("base_url") or "").rstrip("/")
        self.api_key_value = api_key_value

    def _headers(self):
        hdrs = {"User-Agent": "PrismTerminal/0.1"}
        if self.api_key_value:
            hdrs["Authorization"] = f"Bearer {self.api_key_value}"
        return hdrs

    def ping(self, path: str = "/ping") -> dict:
        if not self.base_url:
            return {"ok": False, "error": "Base URL not configured."}
        url = self.base_url + path
        try:
            import requests
            r = requests.get(url, headers=self._headers(), timeout=self.timeout)
            return {"ok": r.ok, "status": r.status_code, "text": r.text[:1000]}
        except Exception as e:
            return {"ok": False, "error": str(e)}
