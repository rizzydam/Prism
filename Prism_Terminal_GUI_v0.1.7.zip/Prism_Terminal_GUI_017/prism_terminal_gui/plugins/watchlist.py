from tkinter import ttk, messagebox
import tkinter as tk
import datetime

def build_ui(parent, services):
    cfg = services["cfg"]; cfgmgr = services["cfgmgr"]; log = services["log"]
    jobs = services["jobs"]; market = services["market"]

    conf = cfg.plugins.setdefault("watchlist", {})
    symbols = conf.setdefault("symbols", ["AAPL","MSFT","SPY"])
    autorefresh = conf.setdefault("autorefresh_sec", 0)
    use_batch = conf.setdefault("batch", True)

    frame = ttk.Frame(parent)
    header = ttk.Frame(frame); header.pack(fill="x", pady=(4,6))
    ttk.Label(header, text="Watchlist", font=("Helvetica", 12, "bold")).pack(side="left")
    status = tk.StringVar(value="Ready")
    ttk.Label(header, textvariable=status).pack(side="right")

    # Left: manage list
    left = ttk.Frame(frame); left.pack(side="left", fill="y", padx=(0,8))
    ttk.Label(left, text="Symbols").pack(anchor="w")
    lst = tk.Listbox(left, height=12, exportselection=False)
    for s in symbols: lst.insert("end", s)
    lst.pack(fill="y")

    btns = ttk.Frame(left); btns.pack(anchor="w", pady=6)
    ttk.Button(btns, text="Add", command=lambda: add_symbol()).pack(side="left", padx=2)
    ttk.Button(btns, text="Remove", command=lambda: remove_symbol()).pack(side="left", padx=2)
    ttk.Button(btns, text="Rename", command=lambda: rename_symbol()).pack(side="left", padx=2)
    ttk.Button(btns, text="Save List", command=lambda: save_symbols()).pack(side="left", padx=10)

    # Right: tiles as a table
    right = ttk.Frame(frame); right.pack(side="left", fill="both", expand=True)
    topbar = ttk.Frame(right); topbar.pack(fill="x", pady=4)
    ttk.Button(topbar, text="Refresh Now", command=lambda: refresh_all()).pack(side="left", padx=2)
    ttk.Label(topbar, text="Auto-refresh (sec)").pack(side="left")
    ent_auto = ttk.Entry(topbar, width=6); ent_auto.insert(0, str(autorefresh)); ent_auto.pack(side="left", padx=4)
    ttk.Button(topbar, text="Set", command=lambda: set_auto()).pack(side="left", padx=2)
    batch_var = tk.BooleanVar(value=use_batch)
    chk = ttk.Checkbutton(topbar, text="Use batch snapshot", variable=batch_var, command=lambda: toggle_batch())
    chk.pack(side="left", padx=12)
    ttk.Button(topbar, text="Open Sparklines Panel", command=lambda: open_sparks()).pack(side="left", padx=12)
    ttk.Button(topbar, text="Clear Cache", command=lambda: (market.clear_cache(), set_status("Cache cleared"))).pack(side="left", padx=8)

    cols = ("symbol","last","change","pct","prev_close","time")
    tree = ttk.Treeview(right, columns=cols, show="headings", height=18)
    for c, w in zip(cols, (80,100,100,80,110,160)):
        tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    tree.pack(fill="both", expand=True)
    tree.tag_configure("up", foreground="#2e7d32")
    tree.tag_configure("down", foreground="#c62828")
    tree.tag_configure("flat", foreground="#444")

    auto_job = {"id": None}

    def set_status(msg):
        status.set(msg)

    def add_symbol():
        nm = prompt("Add symbol", "Ticker (e.g., AAPL)")
        if not nm: return
        nm = nm.strip().upper()
        if nm and nm not in symbols:
            symbols.append(nm); lst.insert("end", nm)

    def remove_symbol():
        sel = lst.curselection()
        if not sel: return
        i = sel[0]; sym = lst.get(i)
        symbols.remove(sym); lst.delete(i)

    def rename_symbol():
        sel = lst.curselection()
        if not sel: return
        i = sel[0]; old = lst.get(i)
        nm = prompt("Rename symbol", "New ticker", old)
        if not nm: return
        nm = nm.strip().upper()
        if nm and nm not in symbols:
            symbols[i] = nm; lst.delete(i); lst.insert(i, nm)

    def save_symbols():
        conf["symbols"] = symbols[:]
        cfgmgr.save(cfg); set_status("Watchlist saved.")

    def set_auto():
        try:
            val = int(ent_auto.get().strip() or "0")
        except Exception:
            messagebox.showerror("Watchlist", "autorefresh must be an integer seconds."); return
        conf["autorefresh_sec"] = val; cfgmgr.save(cfg)
        set_status(f"Auto-refresh set to {val}s."); schedule_auto(val)

    def toggle_batch():
        conf["batch"] = bool(batch_var.get()); cfgmgr.save(cfg)
        set_status(f"Batch snapshot {'enabled' if conf['batch'] else 'disabled'}.")

    def schedule_auto(sec):
        if auto_job.get("id"):
            parent.after_cancel(auto_job["id"])
            auto_job["id"] = None
        if sec and sec > 0:
            def ping():
                refresh_all()
                schedule_auto(conf.get("autorefresh_sec", 0))
            auto_job["id"] = parent.after(sec * 1000, ping)

    def refresh_all():
        # set up rows
        existing = {tree.set(i, "symbol"): i for i in tree.get_children()}
        for s in symbols:
            if s not in existing:
                tree.insert("", "end", values=(s, "—", "—", "—", "—", "—"))
        for sym, item in list(existing.items()):
            if sym not in symbols: tree.delete(item)

        if conf.get("batch", True):
            jobs.enqueue(batch_task, "watchlist:batch", args=(symbols[:],))
            set_status(f"Refreshing {len(symbols)} symbols (batch)...")
        else:
            for s in symbols:
                jobs.enqueue(fetch_symbol, f"watch:{s}", args=(s,))
            set_status(f"Refreshing {len(symbols)} symbols...")

    def batch_task(ctx, syms):
        quotes = market.batch_quotes(syms)
        def ui():
            for sym, q in quotes.items():
                update_row(sym, q)
            set_status(f"Updated {len(quotes)} symbols")
        parent.after(0, ui)

    def fetch_symbol(ctx, sym: str):
        p = market.prev_close(sym); l = market.last_trade(sym)
        prev = p.get("close"); last = l.get("price")
        chg = pct = None
        if isinstance(prev, (int,float)) and isinstance(last, (int,float)):
            chg = last - prev
            if prev != 0: pct = (chg / prev) * 100.0
        ts = l.get("ts")
        row = {"last": last, "prev": prev, "change": chg, "pct": pct, "ts": ts}
        def ui():
            update_row(sym, row); set_status(f"Updated {sym}")
        parent.after(0, ui)

    def update_row(sym, row):
        # find row by symbol
        for item in tree.get_children():
            if tree.set(item, "symbol") == sym:
                last = row.get("last"); prev = row.get("prev"); chg = row.get("change"); pct = row.get("pct"); ts = row.get("ts")
                last_s = f"{last:.2f}" if isinstance(last,(int,float)) else "—"
                prev_s = f"{prev:.2f}" if isinstance(prev,(int,float)) else "—"
                chg_s = f"{chg:+.2f}" if isinstance(chg,(int,float)) else "—"
                pct_s = f"{pct:+.2f}%" if isinstance(pct,(int,float)) else "—"
                tstr = ""
                if isinstance(ts, (int,float)):
                    if ts > 1e12: ts = ts/1000.0
                    if ts > 1e15: ts = ts/1e9
                    try: tstr = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
                    except Exception: tstr = str(ts)
                tree.item(item, values=(sym, last_s, chg_s, pct_s, prev_s, tstr))
                tag = "flat"
                if isinstance(chg,(int,float)):
                    if chg > 0: tag = "up"
                    elif chg < 0: tag = "down"
                tree.item(item, tags=(tag,))
                break

    # --------- Sparklines Panel ---------
    def open_sparks():
        dlg = tk.Toplevel(frame); dlg.title("Sparklines"); dlg.geometry("420x360")
        top = ttk.Frame(dlg); top.pack(fill="x", pady=4)
        ttk.Label(top, text="Lookback (min)").pack(side="left")
        ent_lb = ttk.Entry(top, width=6); ent_lb.insert(0, "60"); ent_lb.pack(side="left", padx=4)
        ttk.Button(top, text="Refresh", command=lambda: refresh_sparks()).pack(side="left", padx=4)
        ttk.Label(top, text="Auto (sec)").pack(side="left")
        ent_auto_s = ttk.Entry(top, width=6); ent_auto_s.insert(0, str(conf.get("autorefresh_sec",0))); ent_auto_s.pack(side="left", padx=4)
        ttk.Button(top, text="Set", command=lambda: set_auto_s()).pack(side="left", padx=4)

        area = ttk.Frame(dlg); area.pack(fill="both", expand=True)
        rows = {}

        auto = {"id": None}

        def set_auto_s():
            try: v = int(ent_auto_s.get().strip() or "0")
            except Exception:
                messagebox.showerror("Sparklines", "Auto must be integer seconds."); return
            schedule_auto_s(v)

        def schedule_auto_s(sec):
            if auto.get("id"):
                dlg.after_cancel(auto["id"]); auto["id"]=None
            if sec and sec>0:
                def ping():
                    refresh_sparks()
                    schedule_auto_s(int(ent_auto_s.get().strip() or "0"))
                auto["id"] = dlg.after(sec*1000, ping)

        def clear_rows():
            for w in area.winfo_children():
                w.destroy()
            rows.clear()

        def refresh_sparks():
            clear_rows()
            try:
                lb = int(ent_lb.get().strip() or "60")
            except Exception:
                lb = 60
            # request minute bars per symbol (could also batch minute bars if provider supports)
            data = {}
            for s in symbols:
                data[s] = market.minutes_bars(s, lb)
            # build rows
            for s in symbols:
                row = ttk.Frame(area); row.pack(fill="x", padx=6, pady=2)
                ttk.Label(row, text=s, width=8).pack(side="left")
                canvas = tk.Canvas(row, height=28, width=300, bg="#ffffff", highlightthickness=1, highlightbackground="#ddd")
                canvas.pack(side="left", fill="x", expand=True)
                draw_spark(canvas, data.get(s, {}))

        def draw_spark(cv, result):
            bars = (result or {}).get("bars") or []
            vals = [b.get("c") for b in bars if isinstance(b.get("c"), (int,float))]
            if len(vals) < 2:
                cv.create_text(8, 14, anchor="w", text="no data", fill="#666"); return
            w = int(cv["width"]); h = int(cv["height"])
            mn = min(vals); mx = max(vals)
            if mx == mn: mx = mn + 1e-6
            N = len(vals)
            xs = [int(i*(w-4)/(N-1))+2 for i in range(N)]
            ys = [int(h-4 - (v-mn)/(mx-mn)*(h-8))+2 for v in vals]
            # draw baseline
            cv.create_line(2, h-10, w-2, h-10, fill="#e5e5e5")
            # draw path
            pts = []
            for x,y in zip(xs, ys): pts.extend([x,y])
            cv.create_line(*pts, fill="#222")
            # last dot
            cv.create_oval(xs[-1]-2, ys[-1]-2, xs[-1]+2, ys[-1]+2, fill="#222", outline="")

        refresh_sparks()
        dlg.transient(frame); dlg.grab_set(); frame.wait_window(dlg)

    # helper prompt
    def prompt(title, label, initial=""):
        dlg = tk.Toplevel(frame); dlg.title(title); dlg.geometry("320x140"); out={"v":None}
        ttk.Label(dlg, text=label).pack(anchor="w", padx=8, pady=(10,0))
        ent = ttk.Entry(dlg); ent.pack(fill="x", padx=8); ent.insert(0, initial)
        row = ttk.Frame(dlg); row.pack(anchor="e", padx=8, pady=10)
        def ok(): out["v"] = ent.get().strip(); dlg.destroy()
        ttk.Button(row, text="OK", command=ok).pack(side="right", padx=6)
        ttk.Button(row, text="Cancel", command=dlg.destroy).pack(side="right")
        dlg.transient(frame); dlg.grab_set(); frame.wait_window(dlg)
        return out["v"]

    schedule_auto(conf.get("autorefresh_sec", 0))
    return frame

PLUGIN = {"name":"Watchlist","version":"0.1.7","api_version":1,"build_ui":build_ui,"description":"Manage tickers, quote tiles, batch snapshots, and sparklines."}
