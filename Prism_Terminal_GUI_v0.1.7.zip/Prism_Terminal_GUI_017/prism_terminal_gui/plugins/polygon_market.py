from tkinter import ttk, messagebox
import tkinter as tk
import requests, json, datetime

def build_ui(parent, services):
    cfg = services["cfg"]; keystore = services["keystore"]

    frame = ttk.Frame(parent)
    ttk.Label(frame, text="Polygon Market (basic)", font=("Helvetica", 12, "bold")).pack(anchor="w", pady=(4,6))

    row1 = ttk.Frame(frame); row1.pack(fill="x", padx=2, pady=2)
    ttk.Label(row1, text="Base URL").pack(side="left")
    ent_base = ttk.Entry(row1, width=40); ent_base.pack(side="left", padx=6)
    ent_base.insert(0, cfg.network.get("base_url") or "https://api.polygon.io")

    ttk.Label(row1, text="API Key Name").pack(side="left", padx=(8,0))
    names = keystore.list_names(cfg) or ["default"]
    cmb_key = ttk.Combobox(row1, values=names, width=12, state="readonly")
    if cfg.keys.get("default") in names: cmb_key.set(cfg.keys.get("default"))
    elif names: cmb_key.set(names[0])
    cmb_key.pack(side="left", padx=6)

    ttk.Label(row1, text="Param").pack(side="left")
    ent_param = ttk.Entry(row1, width=10); ent_param.pack(side="left"); ent_param.insert(0, "apiKey")

    row2 = ttk.Frame(frame); row2.pack(fill="x", padx=2, pady=2)
    ttk.Label(row2, text="Endpoint").pack(side="left")
    cmb_ep = ttk.Combobox(row2, values=[
        "Market Status Now (/v1/marketstatus/now)",
        "Aggregates Daily (/v2/aggs/ticker/{T}/range/1/day/{FROM}/{TO})"
    ], width=54, state="readonly")
    cmb_ep.set("Market Status Now (/v1/marketstatus/now)"); cmb_ep.pack(side="left", padx=6)

    ttk.Label(row2, text="Ticker").pack(side="left")
    ent_ticker = ttk.Entry(row2, width=12); ent_ticker.pack(side="left"); ent_ticker.insert(0, "AAPL")

    row3 = ttk.Frame(frame); row3.pack(fill="x", padx=2, pady=2)
    ttk.Label(row3, text="From (YYYY-MM-DD)").pack(side="left")
    ent_from = ttk.Entry(row3, width=12); ent_from.pack(side="left", padx=6)
    ttk.Label(row3, text="To").pack(side="left")
    ent_to = ttk.Entry(row3, width=12); ent_to.pack(side="left", padx=6)

    btns = ttk.Frame(frame); btns.pack(anchor="w", pady=6)
    ttk.Button(btns, text="Run", command=lambda: run()).pack(side="left", padx=4)

    out = tk.Text(frame, height=16); out.pack(fill="both", expand=True, pady=4)

    def run():
        base = (ent_base.get().strip() or "https://api.polygon.io").rstrip("/")
        name = cmb_key.get() or cfg.keys.get("default"); key = keystore.get(name) if name else None
        if not key: messagebox.showerror("Polygon", "No API key found."); return
        param = (ent_param.get().strip() or "apiKey")
        ep = cmb_ep.get()
        if "Market Status" in ep:
            url = base + "/v1/marketstatus/now"; params = {param: key}
        else:
            tkr = ent_ticker.get().strip() or "AAPL"
            f = ent_from.get().strip() or (datetime.date.today() - datetime.timedelta(days=30)).isoformat()
            to = ent_to.get().strip() or datetime.date.today().isoformat()
            url = base + f"/v2/aggs/ticker/{tkr}/range/1/day/{f}/{to}"
            params = {param: key, "adjusted": "true", "sort": "asc", "limit": "5000"}
        do_request(url, params)

    def do_request(url, params):
        out.configure(state="normal"); out.delete("1.0","end"); out.insert("end", f"GET {url}\n\n"); out.configure(state="disabled")
        def task():
            try:
                r = requests.get(url, params=params, timeout=float(cfg.network.get('timeout', 8.0)))
                try:
                    j = r.json(); content = f"HTTP {r.status_code}\n\n" + json.dumps(j, indent=2)[:100000]
                except Exception:
                    content = f"HTTP {r.status_code}\n\n" + r.text[:100000]
            except Exception as e:
                content = f"Error: {e}"
            def ui():
                out.configure(state="normal"); out.delete("1.0","end"); out.insert("end", content); out.configure(state="disabled")
            parent.after(0, ui)
        services["run_in_thread"](task)

    return frame

PLUGIN = {"name":"Polygon Market","version":"0.1.7","api_version":1,"build_ui":build_ui,"description":"Polygon status and aggregates."}
