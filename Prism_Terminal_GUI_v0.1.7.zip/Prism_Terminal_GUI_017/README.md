# Prism Terminal GUI (v0.1.7)

Upgrade bundle:
- **Watchlist**: new **Sparklines Panel** (Canvas-based, no extra deps). One click, tiny intraday charts for your symbols.
- **MarketData**: `minutes_bars(symbol, lookback_minutes)` using Polygon minute aggregates, with memory + **SQLite TTL cache**.
- **Alerts**: optional **Webhook** delivery (POST JSON) in addition to in-app dialog + logs.
- Prior improvements retained: **Batch snapshot** toggle, **Alerts**, **Jobs**, **Profiles**, **API Explorer**, **Polygon Market**, **Zip Logs**, **Clear Data Cache**.

## Quickstart (Windows)
```
install.bat
run.bat
```

## Quickstart (macOS/Linux)
```bash
chmod +x install.sh run.sh
./install.sh
./run.sh
```

## Notes
- Sparklines draw from minute bars (`/v2/aggs/ticker/{T}/range/1/minute/{from}/{to}`).
- Caching: snapshot=3s, last=5s, prev=60s, minute bars=10s.
