#!/usr/bin/env bash
set -e
source .venv/bin/activate
python -m prism_terminal_gui
