#!/usr/bin/env bash
set -e
PY="${PYTHON_BIN:-python3}"
$PY -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip wheel
pip install -r requirements.txt
echo "✅ Installed. Launch with ./run.sh"
