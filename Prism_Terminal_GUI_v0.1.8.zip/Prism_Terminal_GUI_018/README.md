# Prism Terminal GUI (v0.1.8)

This bundle fixes the Watchlist sparklines (they’re now toggleable and populated) and adds **Alert Routing**
(Slack, Discord, generic Webhook). Prior features: Profiles, Keys, API Explorer, Polygon Market, Jobs, Watchlist,
Alerts (rules), batch snapshots, SQLite TTL cache, Zip Logs, Clear Cache.

**What’s new**
- **Watchlist**
  - Toggle: **Show sparklines** (off by default; saves to `plugins.watchlist.sparklines`).
  - New column: **spark** with Unicode mini-graph.
  - Fetches minute bars via Polygon aggs; respects TTL to avoid rate spikes.
- **MarketData**
  - `minute_bars(symbol, lookback=60)` + `sparkline(values, width=24)`
  - 30s TTL (memory + SQLite).
- **Alert Routing**
  - Manage endpoints under plugin **Alert Routes** (Slack/Discord/Webhook).
  - Alerts plugin now sends to enabled routes, in addition to in‑app dialog.
  - Button: **Test All Routes**.

**Quickstart (Windows)**
```
install.bat
run.bat
```

**Quickstart (macOS/Linux)**
```bash
chmod +x install.sh run.sh
./install.sh
./run.sh
```
