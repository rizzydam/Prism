import os, sys, threading, traceback, zipfile, time
import tkinter as tk
from tkinter import ttk, messagebox

from .branding import header_frame, APP_NAME
from .config import ConfigManager
from .keystore import KeyStore
from .logging_setup import configure_logging
from .client import Client
from .plugins import discover_plugins, Plugin
from .shared.jobs import JobManager
from .shared.market import MarketData
from .shared.notifier import Notifier

def run_in_thread(fn, on_done=None):
    def wrapper():
        try:
            fn()
        finally:
            if on_done:
                try: on_done()
                except Exception: pass
    th = threading.Thread(target=wrapper, daemon=True)
    th.start()
    return th

class MainWindow:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_NAME); self.root.geometry("1120x780")

        self.cfgmgr = ConfigManager(); self.cfg = self.cfgmgr.load()
        self.keystore = KeyStore(self.cfgmgr)
        self.jobs = JobManager(None, max_workers=3)

        self._log_text = None
        self.logger, self.log_file = configure_logging(self.cfgmgr.config_dir, self.cfg.logging.get("level","INFO"), self._gui_log_append)

        self.market = MarketData(self.cfg, self.keystore, self.logger, config_dir=self.cfgmgr.config_dir)
        self.notifier = Notifier(self.cfg, self.logger)

        self.services = {
            "cfg": self.cfg, "cfgmgr": self.cfgmgr, "keystore": self.keystore,
            "logger": self.logger, "log": self.log, "notify": lambda msg: messagebox.showinfo(APP_NAME, msg),
            "run_in_thread": run_in_thread, "get_client": self._make_client,
            "open_config_dir": self.cfgmgr.open_config_dir, "log_file": self.log_file,
            "jobs": self.jobs, "market": self.market, "notifier": self.notifier
        }

        self._build_ui()
        if not self.cfg.app.get("first_run_complete"): self._first_run_wizard()
        self._refresh_dashboard()
        self._discover_plugins()

    def _build_ui(self):
        menubar = tk.Menu(self.root)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open Config Folder", command=self.cfgmgr.open_config_dir)
        filemenu.add_command(label="Open Config File", command=self._open_config_file)
        filemenu.add_command(label="Open Plugin Folder", command=self._open_plugin_folder)
        filemenu.add_command(label="Reload Plugins", command=self._discover_plugins)
        filemenu.add_separator(); filemenu.add_command(label="Quit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=filemenu)

        toolsmenu = tk.Menu(menubar, tearoff=0)
        toolsmenu.add_command(label="Test Connection", command=self._test_connection)
        toolsmenu.add_command(label="Open Logs Folder", command=self._open_logs_folder)
        toolsmenu.add_command(label="Zip Logs", command=self._zip_logs)
        toolsmenu.add_command(label="Clear Data Cache", command=self._clear_data_cache)
        menubar.add_cascade(label="Tools", menu=toolsmenu)

        helpmenu = tk.Menu(menubar, tearoff=0)
        helpmenu.add_command(label="About", command=lambda: messagebox.showinfo(APP_NAME, "Prism Terminal GUI v0.1.8"))
        menubar.add_cascade(label="Help", menu=helpmenu)

        self.root.config(menu=menubar)

        header = header_frame(self.root); header.pack(fill="x", padx=12, pady=8)

        self.notebook = ttk.Notebook(self.root); self.notebook.pack(fill="both", expand=True, padx=12, pady=(0,12))
        self.tab_dashboard = ttk.Frame(self.notebook)
        self.tab_settings = ttk.Frame(self.notebook)
        self.tab_keys = ttk.Frame(self.notebook)
        self.tab_plugins = ttk.Frame(self.notebook)
        self.tab_logs = ttk.Frame(self.notebook)
        self.tab_workspace = ttk.Notebook(self.notebook)
        self.notebook.add(self.tab_dashboard, text="Dashboard")
        self.notebook.add(self.tab_settings, text="Settings")
        self.notebook.add(self.tab_keys, text="Keys")
        self.notebook.add(self.tab_plugins, text="Plugins")
        self.notebook.add(self.tab_logs, text="Logs")
        self.notebook.add(self.tab_workspace, text="Workspace")

        self._build_dashboard(); self._build_settings(); self._build_keys_tab(); self._build_plugins_tab(); self._build_logs_tab()

    def _build_dashboard(self):
        grid = ttk.Frame(self.tab_dashboard); grid.pack(fill="both", expand=True, padx=8, pady=8)
        self.dbg_config_path = tk.StringVar(); self.dbg_log_file = tk.StringVar()
        self.dbg_base_url = tk.StringVar(); self.dbg_plugins = tk.StringVar(value="0")
        ttk.Label(grid, text="Config directory:").grid(row=0, column=0, sticky="w")
        ttk.Label(grid, textvariable=self.dbg_config_path).grid(row=0, column=1, sticky="w")
        ttk.Label(grid, text="Log file:").grid(row=1, column=0, sticky="w")
        ttk.Label(grid, textvariable=self.dbg_log_file).grid(row=1, column=1, sticky="w")
        ttk.Label(grid, text="Base URL:").grid(row=2, column=0, sticky="w")
        ttk.Label(grid, textvariable=self.dbg_base_url).grid(row=2, column=1, sticky="w")
        ttk.Label(grid, text="Plugins discovered:").grid(row=3, column=0, sticky="w")
        ttk.Label(grid, textvariable=self.dbg_plugins).grid(row=3, column=1, sticky="w")
        btns = ttk.Frame(grid); btns.grid(row=4, column=0, columnspan=2, pady=10, sticky="w")
        ttk.Button(btns, text="Test Connection", command=self._test_connection).pack(side="left", padx=4)
        ttk.Button(btns, text="Open Config Folder", command=self.cfgmgr.open_config_dir).pack(side="left", padx=4)
        ttk.Button(btns, text="Open Logs Folder", command=self._open_logs_folder).pack(side="left", padx=4)
        for i in range(2): grid.columnconfigure(i, weight=1)

    def _build_settings(self):
        frm = ttk.Frame(self.tab_settings); frm.pack(fill="x", padx=8, pady=8)
        ttk.Label(frm, text="Base URL").grid(row=0, column=0, sticky="w")
        self.ent_base_url = ttk.Entry(frm, width=60); self.ent_base_url.grid(row=0, column=1, sticky="w")
        ttk.Label(frm, text="Timeout (seconds)").grid(row=1, column=0, sticky="w")
        self.ent_timeout = ttk.Entry(frm, width=10); self.ent_timeout.grid(row=1, column=1, sticky="w")
        save_row = ttk.Frame(frm); save_row.grid(row=2, column=0, columnspan=2, pady=10, sticky="w")
        ttk.Button(save_row, text="Save Settings", command=self._save_settings).pack(side="left", padx=4)
        frm.columnconfigure(1, weight=1)

    def _build_keys_tab(self):
        frm = ttk.Frame(self.tab_keys); frm.pack(fill="both", expand=True, padx=8, pady=8)
        left = ttk.Frame(frm); left.pack(side="left", fill="y")
        right = ttk.Frame(frm); right.pack(side="left", fill="both", expand=True, padx=(12,0))
        ttk.Label(left, text="Keys").pack(anchor="w")
        self.lst_keys = tk.Listbox(left, height=12, exportselection=False); self.lst_keys.pack(fill="y", expand=False)
        self.lst_keys.bind("<<ListboxSelect>>", lambda e: self._on_key_select())
        btns = ttk.Frame(left); btns.pack(anchor="w", pady=6)
        ttk.Button(btns, text="Add", command=self._key_add).pack(side="left", padx=2)
        ttk.Button(btns, text="Edit", command=self._key_edit).pack(side="left", padx=2)
        ttk.Button(btns, text="Delete", command=self._key_delete).pack(side="left", padx=2)
        ttk.Label(right, text="Selected key name:").pack(anchor="w")
        self.key_selected = tk.StringVar(); self.key_val_preview = tk.StringVar(value="(hidden)")
        ttk.Label(right, textvariable=self.key_selected).pack(anchor="w")
        ttk.Label(right, text="Value preview (first 4 chars):").pack(anchor="w", pady=(8,0))
        ttk.Label(right, textvariable=self.key_val_preview).pack(anchor="w")
        default_row = ttk.Frame(right); default_row.pack(anchor="w", pady=8)
        ttk.Label(default_row, text="Default key:").pack(side="left")
        self.cmb_default_key = ttk.Combobox(default_row, state="readonly"); self.cmb_default_key.pack(side="left", padx=6)
        ttk.Button(default_row, text="Set Default", command=self._set_default_key).pack(side="left")

    def _build_plugins_tab(self):
        frm = ttk.Frame(self.tab_plugins); frm.pack(fill="both", expand=True, padx=8, pady=8)
        left = ttk.Frame(frm); left.pack(side="left", fill="both")
        right = ttk.Frame(frm); right.pack(side="left", fill="both", expand=True, padx=(12,0))
        ttk.Label(left, text="Plugins").pack(anchor="w")
        self.lst_plugins = tk.Listbox(left, height=18, exportselection=False); self.lst_plugins.pack(fill="both", expand=True)
        self.lst_plugins.bind("<<ListboxSelect>>", lambda e: self._on_plugin_select())
        btns = ttk.Frame(left); btns.pack(anchor="w", pady=6)
        ttk.Button(btns, text="Run", command=self._plugin_run).pack(side="left", padx=2)
        ttk.Button(btns, text="Open UI", command=self._plugin_open_ui).pack(side="left", padx=2)
        ttk.Button(btns, text="Reload", command=self._discover_plugins).pack(side="left", padx=2)
        self.plugin_info = tk.Text(right, height=12); self.plugin_info.pack(fill="both", expand=True)

    def _build_logs_tab(self):
        frm = ttk.Frame(self.tab_logs); frm.pack(fill="both", expand=True, padx=8, pady=8)
        self._log_text = tk.Text(frm, state="disabled"); self._log_text.pack(fill="both", expand=True)

    def _gui_log_append(self, text: str):
        if self._log_text is None: return
        self._log_text.configure(state="normal"); self._log_text.insert("end", text); self._log_text.see("end"); self._log_text.configure(state="disabled")

    def _refresh_dashboard(self):
        self.dbg_config_path.set(self.cfgmgr.config_dir); self.dbg_log_file.set(self.log_file)
        self.dbg_base_url.set(self.cfg.network.get("base_url") or "(not set)")
        names = self.keystore.list_names(self.cfg)
        self.lst_keys.delete(0, "end"); [self.lst_keys.insert("end", n) for n in names]
        self.cmb_default_key["values"] = names
        if self.cfg.keys.get("default") in names: self.cmb_default_key.set(self.cfg.keys.get("default"))
        elif names: self.cmb_default_key.set(names[0])
        self.ent_base_url.delete(0, "end"); self.ent_base_url.insert(0, self.cfg.network.get("base_url") or "")
        self.ent_timeout.delete(0, "end"); self.ent_timeout.insert(0, str(self.cfg.network.get("timeout", 8.0)))

    def _save_settings(self):
        self.cfg.network["base_url"] = self.ent_base_url.get().strip()
        try: self.cfg.network["timeout"] = float(self.ent_timeout.get().strip())
        except Exception: messagebox.showerror(APP_NAME, "Timeout must be a number."); return
        self.cfgmgr.save(self.cfg); self.log("Settings saved."); self._refresh_dashboard()

    def _open_logs_folder(self):
        path = os.path.dirname(self.log_file)
        if sys.platform.startswith("win"): os.startfile(path)  # type: ignore
        elif sys.platform == "darwin": os.system(f'open "{path}"')
        else: os.system(f'xdg-open "{path}"')

    def _open_plugin_folder(self):
        path = os.path.join(os.path.dirname(__file__), "plugins")
        if sys.platform.startswith("win"): os.startfile(path)  # type: ignore
        elif sys.platform == "darwin": os.system(f'open "{path}"')
        else: os.system(f'xdg-open "{path}"')

    def _open_config_file(self):
        path = self.cfgmgr.config_file
        if sys.platform.startswith("win"): os.startfile(path)  # type: ignore
        elif sys.platform == "darwin": os.system(f'open "{path}"')
        else: os.system(f'xdg-open "{path}"')

    def _zip_logs(self):
        log_dir = os.path.dirname(self.log_file)
        zip_path = os.path.join(log_dir, "logs.zip")
        try:
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
                for root, dirs, files in os.walk(log_dir):
                    for f in files:
                        if f.endswith(".log") or f.endswith(".txt"):
                            full = os.path.join(root, f)
                            rel = os.path.relpath(full, start=log_dir)
                            z.write(full, rel)
            messagebox.showinfo(APP_NAME, f"Logs zipped: {zip_path}")
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Failed to zip logs: {e}")

    def _clear_data_cache(self):
        try:
            self.market.clear_cache()
            messagebox.showinfo(APP_NAME, "Data cache cleared.")
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Failed to clear cache: {e}")

    def _make_client(self) -> Client:
        default_key_name = self.cfg.keys.get("default")
        key_val = self.keystore.get(default_key_name) if default_key_name else None
        return Client(self.cfg, key_val)

    def _test_connection(self):
        client = self._make_client()
        def task():
            res = client.ping()
            def ui():
                if res.get("ok"): self.log(f"Ping OK ({res.get('status')})."); messagebox.showinfo(APP_NAME, f"Ping OK ({res.get('status')}).")
                else: self.log(f"Ping failed: {res.get('error', res)}"); messagebox.showwarning(APP_NAME, f"Ping failed: {res.get('error', res)}")
            self.root.after(0, ui)
        run_in_thread(task)

    def _on_key_select(self):
        idxs = self.lst_keys.curselection()
        if not idxs: return
        name = self.lst_keys.get(idxs[0]); self.key_selected.set(name)
        val = self.keystore.get(name); self.key_val_preview.set(val[:4] + "…" if val and len(val) > 4 else (val or "(not set)"))

    def _key_add(self):
        self._key_dialog(mode="add")

    def _key_edit(self):
        idxs = self.lst_keys.curselection()
        if not idxs: messagebox.showinfo(APP_NAME, "Select a key to edit."); return
        name = self.lst_keys.get(idxs[0]); self._key_dialog(mode="edit", name=name)

    def _key_delete(self):
        idxs = self.lst_keys.curselection()
        if not idxs: messagebox.showinfo(APP_NAME, "Select a key to delete."); return
        name = self.lst_keys.get(idxs[0])
        if messagebox.askyesno(APP_NAME, f"Delete key '{name}'?"):
            self.keystore.delete(name, self.cfg); self.cfgmgr.save(self.cfg); self.log(f"Deleted key: {name}"); self._refresh_dashboard()

    def _set_default_key(self):
        name = self.cmb_default_key.get()
        if not name: messagebox.showinfo(APP_NAME, "Select a default key."); return
        self.cfg.keys["default"] = name; self.cfgmgr.save(self.cfg); self.log(f"Default key set: {name}")

    def _key_dialog(self, mode="add", name=""):
        dlg = tk.Toplevel(self.root); dlg.title("Add Key" if mode=="add" else f"Edit Key '{name}'"); dlg.geometry("380x180")
        ttk.Label(dlg, text="Key Name").pack(anchor="w", padx=8, pady=(8,0))
        ent_name = ttk.Entry(dlg); ent_name.pack(fill="x", padx=8)
        ttk.Label(dlg, text="Key Value").pack(anchor="w", padx=8, pady=(8,0))
        ent_val = ttk.Entry(dlg, show="*"); ent_val.pack(fill="x", padx=8)

        if mode == "edit": ent_name.insert(0, name); ent_name.configure(state="disabled")
        row = ttk.Frame(dlg); row.pack(anchor="e", pady=12, padx=8)
        def on_ok():
            nm = name if mode=="edit" else ent_name.get().strip(); val = ent_val.get().strip()
            if not nm: messagebox.showerror(APP_NAME, "Name is required."); return
            if not val and mode=="add": messagebox.showerror(APP_NAME, "Value is required."); return
            if val: self.keystore.set(nm, val, self.cfg)
            self.cfgmgr.save(self.cfg); self.log(f"Saved key: {nm}"); dlg.destroy(); self._refresh_dashboard()
        ttk.Button(row, text="Save", command=on_ok).pack(side="right", padx=4)
        ttk.Button(row, text="Cancel", command=dlg.destroy).pack(side="right", padx=4)

    def _discover_plugins(self):
        plugin_dir = os.path.join(os.path.dirname(__file__), "plugins")
        self.plugins = discover_plugins(plugin_dir, self.logger)
        self.lst_plugins.delete(0, "end")
        for p in self.plugins: self.lst_plugins.insert("end", f"{p.name}  v{p.version}")
        self.dbg_plugins.set(str(len(self.plugins)))
        self.plugin_info.configure(state="normal"); self.plugin_info.delete("1.0", "end")
        for p in self.plugins:
            self.plugin_info.insert("end", f"{p.name} (v{p.version}) - API {p.api_version}\n")
            if p.description: self.plugin_info.insert("end", f"  {p.description}\n")
        self.plugin_info.configure(state="disabled")

    def _selected_plugin(self):
        idxs = self.lst_plugins.curselection()
        return self.plugins[idxs[0]] if idxs else None

    def _on_plugin_select(self): pass

    def _plugin_run(self):
        p = self._selected_plugin()
        if not p: messagebox.showinfo(APP_NAME, "Select a plugin to run."); return
        if not p.entry: messagebox.showwarning(APP_NAME, "This plugin has no 'entry' action."); return
        services = self.services
        def run():
            try: p.entry(services)
            except Exception as e:
                self.log(f"Plugin error: {e}"); traceback.print_exc()
                self.root.after(0, lambda: messagebox.showerror(APP_NAME, f"Plugin error: {e}"))
        run_in_thread(run)

    def _plugin_open_ui(self):
        p = self._selected_plugin()
        if not p: messagebox.showinfo(APP_NAME, "Select a plugin to open UI."); return
        if not p.build_ui: messagebox.showwarning(APP_NAME, "This plugin has no UI."); return
        try:
            tab = ttk.Frame(self.tab_workspace); inner = p.build_ui(tab, self.services)
            if inner and hasattr(inner, "pack"): inner.pack(fill="both", expand=True)
            self.tab_workspace.add(tab, text=p.name); self.notebook.select(self.tab_workspace)
        except Exception as e:
            self.log(f"Plugin UI error: {e}"); messagebox.showerror(APP_NAME, f"Plugin UI error: {e}")

    def log(self, msg: str):
        try: self.logger.info(msg)
        except Exception: pass

    def _first_run_wizard(self):
        dlg = tk.Toplevel(self.root); dlg.title("Welcome to Prism Terminal"); dlg.geometry("520x260")
        ttk.Label(dlg, text="Base URL", font=("Helvetica", 10, "bold")).pack(anchor="w", padx=8, pady=(10,0))
        ent_url = ttk.Entry(dlg); ent_url.pack(fill="x", padx=8); ent_url.insert(0, self.cfg.network.get("base_url") or "")
        ttk.Label(dlg, text="Default API Key Name").pack(anchor="w", padx=8, pady=(10,0))
        ent_name = ttk.Entry(dlg); ent_name.pack(fill="x", padx=8); ent_name.insert(0, self.cfg.keys.get("default") or "default")
        ttk.Label(dlg, text="Default API Key Value (optional)").pack(anchor="w", padx=8, pady=(10,0))
        ent_val = ttk.Entry(dlg, show="*"); ent_val.pack(fill="x", padx=8)
        row = ttk.Frame(dlg); row.pack(anchor="e", padx=8, pady=12)
        def on_ok():
            self.cfg.network["base_url"] = ent_url.get().strip()
            default_name = ent_name.get().strip() or "default"; self.cfg.keys["default"] = default_name
            if ent_val.get().strip(): self.keystore.set(default_name, ent_val.get().strip(), self.cfg)
            self.cfg.app["first_run_complete"] = True; self.cfgmgr.save(self.cfg); self._refresh_dashboard(); dlg.destroy()
        ttk.Button(row, text="Start", command=on_ok).pack(side="right", padx=6)
        ttk.Button(row, text="Skip", command=lambda: (self._skip_first_run(dlg))).pack(side="right")
        dlg.transient(self.root); dlg.grab_set(); self.root.wait_window(dlg)

    def _skip_first_run(self, dlg):
        self.cfg.app["first_run_complete"] = True; self.cfgmgr.save(self.cfg); self._refresh_dashboard(); dlg.destroy()

def main():
    root = tk.Tk(); app = MainWindow(root); root.mainloop()

def cli_entry(): main()
