import requests

class Notifier:
    """Send alert messages to configured routes (slack, discord, webhook)."""
    def __init__(self, cfg, logger=None):
        self.cfg = cfg
        self.logger = logger

    def _routes(self):
        return self.cfg.plugins.setdefault("routes", {}).setdefault("items", [])

    def list(self):
        return list(self._routes())

    def add(self, item):
        arr = self._routes(); arr.append(item)

    def update(self, idx, item):
        arr = self._routes()
        if 0 <= idx < len(arr): arr[idx] = item

    def delete(self, idx):
        arr = self._routes()
        if 0 <= idx < len(arr): arr.pop(idx)

    def send_all(self, title: str, message: str, data=None):
        hits = 0
        for r in self._routes():
            if not r.get("enabled", True): continue
            try:
                if self._send_one(r, title, message, data): hits += 1
            except Exception as e:
                if self.logger: self.logger.warning("Route error for %s: %s", r.get("name","route"), e)
        return hits

    def _send_one(self, route, title, message, data=None):
        typ = (route.get("type") or "").lower()
        url = route.get("url") or ""
        if not url: return False
        if typ == "slack":
            payload = {"text": f"*{title}*\n{message}"}
        elif typ == "discord":
            payload = {"content": f"**{title}**\n{message}"}
        else:
            payload = {"title": title, "message": message, "data": data}
        r = requests.post(url, json=payload, timeout=6)
        return r.ok
