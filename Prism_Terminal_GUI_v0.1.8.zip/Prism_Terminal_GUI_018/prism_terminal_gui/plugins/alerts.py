from tkinter import ttk, messagebox
import tkinter as tk

RULE_TYPES = ["Price ≥","Price ≤","% Change ≥","% Change ≤"]

def build_ui(parent, services):
    cfg = services["cfg"]; cfgmgr = services["cfgmgr"]; market = services["market"]; jobs = services["jobs"]; log = services["log"]
    notifier = services["notifier"]
    conf = cfg.plugins.setdefault("alerts", {})
    rules = conf.setdefault("rules", [])
    interval = conf.setdefault("interval_sec", 0)
    route_inapp = conf.setdefault("route_in_app", True)
    route_ext = conf.setdefault("route_external", True)

    frame = ttk.Frame(parent)
    ttk.Label(frame, text="Alerts", font=("Helvetica", 12, "bold")).pack(anchor="w", pady=(4,6))
    top = ttk.Frame(frame); top.pack(fill="x")

    ttk.Button(top, text="Evaluate Now", command=lambda: evaluate_now()).pack(side="left", padx=4)
    ttk.Label(top, text="Auto-evaluate (sec)").pack(side="left")
    ent_ivl = ttk.Entry(top, width=6); ent_ivl.insert(0, str(interval)); ent_ivl.pack(side="left", padx=4)
    ttk.Button(top, text="Set", command=lambda: set_interval()).pack(side="left", padx=4)
    in_var = tk.BooleanVar(value=route_inapp)
    ex_var = tk.BooleanVar(value=route_ext)
    ttk.Checkbutton(top, text="Notify in-app", variable=in_var, command=lambda: toggle_in()).pack(side="left", padx=12)
    ttk.Checkbutton(top, text="Notify routes", variable=ex_var, command=lambda: toggle_ex()).pack(side="left", padx=12)
    ttk.Button(top, text="Test All Routes", command=lambda: test_routes()).pack(side="left", padx=6)

    cols = ("symbol","rule","value")
    tree = ttk.Treeview(frame, columns=cols, show="headings", height=12)
    for c, w in zip(cols, (100,140,120)):
        tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    tree.pack(fill="both", expand=True, pady=6)

    btns = ttk.Frame(frame); btns.pack(anchor="w", pady=6)
    ttk.Button(btns, text="Add", command=lambda: add_rule()).pack(side="left", padx=2)
    ttk.Button(btns, text="Edit", command=lambda: edit_rule()).pack(side="left", padx=2)
    ttk.Button(btns, text="Delete", command=lambda: delete_rule()).pack(side="left", padx=2)

    status = tk.StringVar(value="Ready")
    ttk.Label(frame, textvariable=status).pack(anchor="w", pady=(6,0))

    auto_job = {"id": None}

    def refresh():
        tree.delete(*tree.get_children())
        for r in rules:
            tree.insert("", "end", values=(r.get("symbol",""), r.get("type",""), str(r.get("value",""))))

    def set_interval():
        try: v = int(ent_ivl.get().strip() or "0")
        except Exception:
            messagebox.showerror("Alerts", "Interval must be an integer."); return
        conf["interval_sec"] = v; cfgmgr.save(cfg); schedule_auto(v)

    def schedule_auto(sec):
        if auto_job.get("id"):
            parent.after_cancel(auto_job["id"]); auto_job["id"] = None
        if sec and sec > 0:
            def ping():
                evaluate_now()
                schedule_auto(conf.get("interval_sec", 0))
            auto_job["id"] = parent.after(sec * 1000, ping)

    def evaluate_now():
        syms = sorted({r.get("symbol","").upper() for r in rules if r.get("symbol")})
        if not syms:
            status.set("No rules."); return
        def task(ctx):
            quotes = market.batch_quotes(syms)
            hits = []
            for r in rules:
                sym = r.get("symbol","").upper()
                q = quotes.get(sym) or {}
                last = q.get("last"); prev = q.get("prev"); pct = q.get("pct")
                rt = r.get("type"); val = r.get("value")
                ok = False
                if rt == "Price ≥" and isinstance(last,(int,float)): ok = last >= float(val)
                elif rt == "Price ≤" and isinstance(last,(int,float)): ok = last <= float(val)
                elif rt == "% Change ≥" and isinstance(pct,(int,float)): ok = pct >= float(val)
                elif rt == "% Change ≤" and isinstance(pct,(int,float)): ok = pct <= float(val)
                if ok:
                    hits.append((sym, rt, val, last, pct))
            def ui():
                if not hits:
                    status.set("No alerts triggered"); return
                lines = [f"{s} {t} {v}  (last={l}, pct={p}%)" for s,t,v,l,p in hits]
                msg = "\n".join(lines)
                if in_var.get():
                    messagebox.showinfo("Alerts triggered", msg)
                if ex_var.get():
                    notifier.send_all("Prism Alerts", msg, data={"hits": hits})
                log(f"Alerts:\n{msg}")
                status.set(f"Alerts: {len(hits)} triggered")
            parent.after(0, ui)
        jobs.enqueue(task, "alerts:evaluate")

    def toggle_in():
        conf["route_in_app"] = bool(in_var.get()); cfgmgr.save(cfg)

    def toggle_ex():
        conf["route_external"] = bool(ex_var.get()); cfgmgr.save(cfg)

    def test_routes():
        jobs.enqueue(lambda ctx: notifier.send_all("Prism: Route Test", "This is a test from Prism Terminal."), "routes:test")

    def selected_idx():
        sel = tree.selection()
        if not sel: return None
        return tree.index(sel[0])

    def add_rule():
        r = rule_dialog()
        if not r: return
        rules.append(r); cfgmgr.save(cfg); refresh()

    def edit_rule():
        i = selected_idx()
        if i is None: return
        r = rules[i]
        rr = rule_dialog(r)
        if not rr: return
        rules[i] = rr; cfgmgr.save(cfg); refresh()

    def delete_rule():
        i = selected_idx()
        if i is None: return
        rules.pop(i); cfgmgr.save(cfg); refresh()

    def rule_dialog(existing=None):
        dlg = tk.Toplevel(frame); dlg.title("Rule"); dlg.geometry("360x220"); out={"v":None}
        ttk.Label(dlg, text="Symbol").pack(anchor="w", padx=8, pady=(8,0))
        ent_sym = ttk.Entry(dlg); ent_sym.pack(fill="x", padx=8)
        ttk.Label(dlg, text="Type").pack(anchor="w", padx=8, pady=(8,0))
        cmb_type = ttk.Combobox(dlg, values=RULE_TYPES, state="readonly"); cmb_type.pack(fill="x", padx=8)
        ttk.Label(dlg, text="Value").pack(anchor="w", padx=8, pady=(8,0))
        ent_val = ttk.Entry(dlg); ent_val.pack(fill="x", padx=8)
        if existing:
            ent_sym.insert(0, existing.get("symbol","")); cmb_type.set(existing.get("type", RULE_TYPES[0])); ent_val.insert(0, str(existing.get("value","")))
        else:
            cmb_type.set(RULE_TYPES[0])
        row = ttk.Frame(dlg); row.pack(anchor="e", padx=8, pady=10)
        def ok():
            sym = ent_sym.get().strip().upper(); typ = cmb_type.get().strip(); val = ent_val.get().strip()
            if not sym or not typ or not val: messagebox.showerror("Alerts", "All fields required."); return
            try: float(val)
            except Exception: messagebox.showerror("Alerts", "Value must be a number."); return
            out["v"] = {"symbol": sym, "type": typ, "value": float(val)}; dlg.destroy()
        ttk.Button(row, text="Save", command=ok).pack(side="right", padx=6)
        ttk.Button(row, text="Cancel", command=dlg.destroy).pack(side="right")
        dlg.transient(frame); dlg.grab_set(); frame.wait_window(dlg)
        return out["v"]

    refresh(); schedule_auto(conf.get("interval_sec", 0))
    return frame

PLUGIN = {"name":"Alerts","version":"0.1.8","api_version":1,"build_ui":build_ui,"description":"Rules with in-app and routed notifications."}
