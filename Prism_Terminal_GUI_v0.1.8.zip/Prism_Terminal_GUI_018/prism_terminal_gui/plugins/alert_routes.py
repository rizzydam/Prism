from tkinter import ttk, messagebox
import tkinter as tk

def build_ui(parent, services):
    cfg = services["cfg"]; cfgmgr = services["cfgmgr"]; notifier = services["notifier"]; log = services["log"]

    conf = cfg.plugins.setdefault("routes", {})
    items = conf.setdefault("items", [])

    frame = ttk.Frame(parent)
    ttk.Label(frame, text="Alert Routes", font=("Helvetica", 12, "bold")).pack(anchor="w", pady=(4,6))

    cols = ("name","type","url","enabled")
    tree = ttk.Treeview(frame, columns=cols, show="headings", height=12)
    for c, w in zip(cols, (160,100,520,80)):
        tree.heading(c, text=c); tree.column(c, width=w, anchor="w")
    tree.pack(fill="both", expand=True)

    btns = ttk.Frame(frame); btns.pack(anchor="w", pady=6)
    ttk.Button(btns, text="Add", command=lambda: edit_route()).pack(side="left", padx=2)
    ttk.Button(btns, text="Edit", command=lambda: on_edit()).pack(side="left", padx=2)
    ttk.Button(btns, text="Delete", command=lambda: on_delete()).pack(side="left", padx=2)
    ttk.Button(btns, text="Enable/Disable", command=lambda: on_toggle()).pack(side="left", padx=2)
    ttk.Button(btns, text="Test Selected", command=lambda: on_test_sel()).pack(side="left", padx=8)
    ttk.Button(btns, text="Test All", command=lambda: on_test_all()).pack(side="left", padx=2)

    status = tk.StringVar(value="Ready")
    ttk.Label(frame, textvariable=status).pack(anchor="w", pady=(6,0))

    def refresh():
        tree.delete(*tree.get_children())
        for r in items:
            tree.insert("", "end", values=(r.get("name",""), r.get("type","webhook"), r.get("url",""), "yes" if r.get("enabled",True) else "no"))

    def selected_idx():
        sel = tree.selection()
        if not sel: return None
        return tree.index(sel[0])

    def on_edit():
        i = selected_idx()
        if i is None: messagebox.showinfo("Routes", "Select a route to edit."); return
        r = items[i]
        rr = route_dialog(r)
        if not rr: return
        items[i] = rr; cfgmgr.save(cfg); refresh()

    def on_delete():
        i = selected_idx()
        if i is None: return
        items.pop(i); cfgmgr.save(cfg); refresh()

    def on_toggle():
        i = selected_idx()
        if i is None: return
        items[i]["enabled"] = not items[i].get("enabled", True)
        cfgmgr.save(cfg); refresh()

    def edit_route(existing=None):
        rr = route_dialog(existing)
        if not rr: return
        items.append(rr); cfgmgr.save(cfg); refresh()

    def route_dialog(existing=None):
        dlg = tk.Toplevel(frame); dlg.title("Route"); dlg.geometry("560x200"); out={"v":None}
        ttk.Label(dlg, text="Name").pack(anchor="w", padx=8, pady=(8,0))
        ent_name = ttk.Entry(dlg); ent_name.pack(fill="x", padx=8)
        ttk.Label(dlg, text="Type (slack / discord / webhook)").pack(anchor="w", padx=8, pady=(8,0))
        cmb_type = ttk.Combobox(dlg, values=["slack","discord","webhook"], state="readonly"); cmb_type.set("webhook"); cmb_type.pack(fill="x", padx=8)
        ttk.Label(dlg, text="URL").pack(anchor="w", padx=8, pady=(8,0))
        ent_url = ttk.Entry(dlg); ent_url.pack(fill="x", padx=8)
        enabled_var = tk.BooleanVar(value=True)
        chk = ttk.Checkbutton(dlg, text="Enabled", variable=enabled_var); chk.pack(anchor="w", padx=8, pady=(8,0))

        if existing:
            ent_name.insert(0, existing.get("name",""))
            cmb_type.set(existing.get("type","webhook"))
            ent_url.insert(0, existing.get("url",""))
            enabled_var.set(existing.get("enabled", True))

        row = ttk.Frame(dlg); row.pack(anchor="e", padx=8, pady=10)
        def ok():
            name = ent_name.get().strip(); typ = cmb_type.get().strip(); url = ent_url.get().strip()
            if not name or not typ or not url:
                messagebox.showerror("Routes", "All fields required."); return
            out["v"] = {"name": name, "type": typ, "url": url, "enabled": bool(enabled_var.get())}
            dlg.destroy()
        ttk.Button(row, text="Save", command=ok).pack(side="right", padx=6)
        ttk.Button(row, text="Cancel", command=dlg.destroy).pack(side="right")
        dlg.transient(frame); dlg.grab_set(); frame.wait_window(dlg)
        return out["v"]

    def on_test_sel():
        i = selected_idx()
        if i is None: return
        r = items[i]
        try:
            ok = services["notifier"]._send_one(r, "Prism: Test Route", "Hello from Prism Terminal")
            messagebox.showinfo("Routes", f"Test {'OK' if ok else 'failed'} for {r.get('name')}")
        except Exception as e:
            messagebox.showerror("Routes", f"Test failed: {e}")

    def on_test_all():
        try:
            n = services["notifier"].send_all("Prism: Test All Routes", "Broadcast test from Prism Terminal")
            messagebox.showinfo("Routes", f"Sent to {n} route(s).")
        except Exception as e:
            messagebox.showerror("Routes", f"Broadcast failed: {e}")

    refresh()
    return frame

PLUGIN = {"name":"Alert Routes","version":"0.1.8","api_version":1,"build_ui":build_ui,"description":"Manage Slack/Discord/Webhook endpoints for alerts."}
