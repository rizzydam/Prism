import os, importlib.util
from dataclasses import dataclass
from typing import Optional, Callable, Any, Dict, List

API_VERSION = 1

@dataclass
class Plugin:
    name: str
    version: str
    api_version: int
    module_name: str
    path: str
    entry: Optional[Callable[[Any], None]] = None
    build_ui: Optional[Callable[[Any, Any], Any]] = None
    description: str = ""

def discover_plugins(plugin_dir: str, logger=None) -> List[Plugin]:
    plugins: List[Plugin] = []
    if not os.path.isdir(plugin_dir): return plugins
    for fname in os.listdir(plugin_dir):
        if not fname.endswith(".py") or fname.startswith("_"): continue
        path = os.path.join(plugin_dir, fname)
        mod_name = f"plugins.{fname[:-3]}"
        try:
            spec = importlib.util.spec_from_file_location(mod_name, path)
            if not spec or not spec.loader: continue
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)  # type: ignore
            plugin_spec: Dict[str, Any] = getattr(mod, "PLUGIN", None)  # type: ignore
            if not plugin_spec or not isinstance(plugin_spec, dict):
                if logger: logger.warning("Skipping %s: missing PLUGIN spec", fname)
                continue
            api_ver = int(plugin_spec.get("api_version", 1))
            if api_ver != API_VERSION:
                if logger: logger.warning("Skipping %s: plugin API %s incompatible with app API %s", fname, api_ver, API_VERSION)
                continue
            p = Plugin(
                name=plugin_spec.get("name", fname[:-3]),
                version=plugin_spec.get("version", "0.0.0"),
                api_version=api_ver,
                module_name=mod_name,
                path=path,
                entry=plugin_spec.get("entry"),
                build_ui=plugin_spec.get("build_ui"),
                description=plugin_spec.get("description", ""),
            )
            plugins.append(p)
        except Exception as e:
            if logger: logger.exception("Failed to load plugin %s: %s", fname, e)
    return plugins
